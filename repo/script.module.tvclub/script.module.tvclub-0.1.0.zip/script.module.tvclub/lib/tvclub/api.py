# -*- coding: utf-8 -*-

import hashlib
import time as timer

import requests

VERSION = '0.8'


LOGO = {
    '36_0': '36_36_0',
    '36_1': '36_36_1',
    '48_0': '48_48_0',
    '48_1': '48_48_1',
    '72_0': '72_72_0',
    '72_1': '72_72_1',
    '90_0': '90_50_0',
    '90_1': '90_50_1',
    '96_0': '96_96_0',
    '96_1': '96_96_1',
    '200_0': '200_115_0',
    '200_1': '200_115_1',
    '300_0': '300_170_0',
    '300_1': '300_170_1',
    '490_0': 'original',
    '490_1': '490_280_1'
}


class TVClubError(Exception):
    def __init__(self, code, msg):
        self.code = code
        self.msg = msg
        Exception.__init__(self, str(self))

    def __str__(self):
        return "TVClubError(code = '%s', msg = '%s')" % (self.code, self.msg)


class TVClub:
    def __init__(self, login=None, password=None):
        self.login = login
        self.password = password
        self._token = None
        self._expire = 0

    def auth(self, login=None, password=None):
        if not login:
            login = self.login
        if not login:
            raise TVClubError(4, 'Incorrect login')
        if not password:
            password = self.password
        if not password:
            raise TVClubError(4, 'Incorrect password')
        sid = hashlib.md5(login + hashlib.md5(password).hexdigest()).hexdigest()
        response = self._execute('auth', {'hash': sid})
        self.login, self.password = login, password
        return response

    def account(self):
        return self._execute('account')

    def logout(self):
        self._execute('logout')
        self._expire, self._token = 0, None
        return {'destroyed': True}

    def groups(self):
        return self._execute('groups')

    def channels(self, gid, sort=None, limit=None, page=None):
        params = {
            'gid': self._number(gid, min=1),
            'sort': self._number(sort, min=1, max=3),
            'limit': self._number(limit, min=1, max=200),
            'page': self._number(page, min=1)
        }
        return self._execute('channels', params)

    def live(self, cid, protected='0000'):
        params = {
            'cid': self._number(cid, min=1),
            'protected': protected
        }
        return self._execute('live', params)

    def rec(self, cid, time, protected='0000'):
        params = {
            'cid': self._number(cid, min=1),
            'time': self._number(time, min=1),
            'protected': protected
        }
        return self._execute('rec', params)

    def epg(self, sort=None, desc_limit=None, time=None, period=None, c_to=None, channels=None, gid=None):
        params = {
            'sort': self._number(sort, min=1, max=3),
            'desc_limit': self._number(desc_limit, min=0)
        }

        c_to = self._number(c_to, min=1, max=20)
        if c_to:
            params['c_to'] = c_to
        else:
            params['period'] = self._number(period, min=1)
            if params['period']:
                params['time'] = self._number(time, min=1)

        gid = self._number(gid, min=1)
        if gid:
            params['gid'] = gid
        elif channels:
            if isinstance(channels, basestring):
                channels = channels.split(',')
            if isinstance(channels, (list, tuple)):
                channels = [y for y in [self._number(x, min=1) for x in channels] if y]
                if channels:
                    params['channels'] = ','.join([str(x) for x in channels])
            else:
                channel = self._number(channels, min=1)
                if channel:
                    params['channels'] = str(channel)

        return self._execute('epg', params)

    def settings(self):
        return self._execute('settings')

    def set(self, timezone=None, server=None, new_code=None, old_code=None):
        params = {
            'timezone': timezone,
            'server': self._number(server, min=1)
        }
        if new_code and old_code:
            params['new_code'] = new_code
            params['old_code'] = old_code
        return self._execute('set', params)

    def favorites(self):
        return self._execute('favorites')

    def set_favorites(self, cid, pos=None, show_current=False):
        params = {
            'cid': self._number(cid, min=1)
        }
        if pos:
            if pos in ('del', 'first', 'last'):
                params['pos'] = pos
            else:
                params['pos'] = self._number(pos, min=1)
        if show_current:
            params['show_current'] = 1
        return self._execute('set_favorites', params)

    def logo(self, cid, size=None, border=False):
        if not size:
            size = 36
        logo = '_'.join([str(size), ('1' if border else '0')])
        if logo not in LOGO:
            logo = '36_0'
        return 'http://tvclub.us/logo/%s/%s.png' % (LOGO[logo], cid)

    # Private method

    def _execute(self, method, params=None):
        params = dict([(k, v) for k, v in params.iteritems() if v is not None]) if params else {}
        if method != 'auth':
            if int(timer.time()) > self._expire:
                self.auth()
            params['token'] = self._token
        first = True
        while True:
            try:
                r = requests.get('http://api.iptv.so/' + VERSION + '/json/' + method, params)
            except requests.exceptions.RequestException, e:
                raise TVClubError(e.response.status_code if e.response else 0, 'RequestException: ' + str(e))
            else:
                response = r.json()
                if isinstance(response.get('session'), dict) and len(response['session'].get('token', '')) == 32:
                    self._token = response['session']['token']
                    self._expire = int(timer.time()) + response['session']['expire'] - response['session']['now']
                if 'error' in response:
                    if first and method != 'auth' and response['error']['code'] in (5, 6, 16):  # session expired
                        self._expire = 0
                        first = False
                        self.auth()
                    else:
                        raise TVClubError(response['error']['code'], response['error']['msg'])
                else:
                    return response

    def _number(self, value, min=None, max=None):
        if value is None:
            return
        try:
            value = int(value)
        except ValueError:
            return
        if min is not None and value < min:
            return
        if max is not None and value > max:
            return
        return value
