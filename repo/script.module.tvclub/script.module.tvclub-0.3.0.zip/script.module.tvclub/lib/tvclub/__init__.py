import xbmcaddon

from api import TVClubError
from api import TVClub as TVClubAPI

__all__ = ['TVClub', 'TVClubError']


class TVClub(TVClubAPI):
    def __init__(self, login=None, password=None):
        addon = xbmcaddon.Addon('script.module.tvclub')
        self.login = addon.getSetting('login')
        self.password = addon.getSetting('password')
        self._token = addon.getSetting('token')
        self._expire = int(addon.getSetting('expire'))
        if login:
            self.login = login
        if password:
            self.password = password

    def _execute(self, method, params=None):
        response = TVClubAPI._execute(self, method, params)
        if method == 'logout':
            login, password, token, expire = '', '', '', 0
        else:
            login, password, token, expire = self.login, self.password, self._token, self._expire
        addon = xbmcaddon.Addon('script.module.tvclub')
        addon.setSetting('login', login)
        addon.setSetting('password', password)
        addon.setSetting('token', token)
        addon.setSetting('expire', str(expire))
        return response
