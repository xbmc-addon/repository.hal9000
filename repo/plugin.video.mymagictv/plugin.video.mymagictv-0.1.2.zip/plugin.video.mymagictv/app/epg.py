# -*- coding: utf-8 -*-

import time
import os.path

import xbmc

import xbmcup.app

from mymagictv import MyMagicTV


class EPG:
    def __init__(self):
        self.login = None
        self.password = None
        self.server = None
        self.quality = None
        self.path = None
        self.last = 0
        self.lock = False

    def loop(self):
        if self.lock:
            return
        self.lock = True

        setting = xbmcup.app.Setting()
        login = setting['login']
        password = setting['password']
        server = setting['server']
        quality = setting['quality']
        path = setting['path']
        if self.path != path and (setting['epg'] != '1' or not os.path.isdir(path)):
            path = None

        if self.login != login or self.password != password or self.server != server or self.quality != quality or self.path != path or self.last + 12*60*60 < int(time.time()):
            try:
                self._make(login, password, server, quality, path)
            except Exception, e:
                xbmc.log(msg='[plugin.video.mymagictv] Unknown exception: %s' % str(e), level=xbmc.LOGERROR)
            else:
                self.login = login
                self.password = password
                self.server = server
                self.quality = quality
                self.path = path
                self.last = int(time.time())

        self.lock = False

    def _make(self, login, password, server, quality, path):
        if login and password:
            start = int(time.time())
            m3u = MyMagicTV(xbmc.translatePath('special://temp/mymagictv'), login, password, server, quality).m3u
            m3u.make()
            if not path:
                self._log('M3U', start)
            else:
                if not m3u.files.copy('tv.m3u', os.path.join(path, 'mymagictv.playlist.m3u')):
                    raise Exception('Unable to copy M3U file to EPG directory')
                self._log('M3U', start)

                start = int(time.time())
                xmltv = MyMagicTV(xbmc.translatePath('special://temp/mymagictv')).xmltv
                xmltv.make()
                if not xmltv.files.copy('tvg.xml', os.path.join(path, 'mymagictv.xmltv.xml')):
                    raise Exception('Unable to copy XMLTV file to EPG directory')
                self._log('XMLTV', start)

    def _log(self, name, start):
        xbmc.log(msg='[plugin.video.mymagictv] %s updated. Time: %s sec' % (name, (int(time.time()) - start)), level=xbmc.LOGNOTICE)
