# -*- coding: utf-8 -*-

import os
from zipfile import ZipFile
from contextlib import closing

import requests

from files import Files


class XMLTV:
    def __init__(self, basedir):
        self.files = Files(os.path.join(basedir, 'xmltv'))

    def make(self):
        session = self.files.transaction()
        fd = session.open('tvg.zip', 'w')
        with closing(requests.get('http://tvg.mymagic.tv/tvg.zip', stream=True)) as r:
            chunk_size = int(float(r.headers['content-length'])/100.0)
            if not chunk_size:
                chunk_size = 1
            for content in r.iter_content(chunk_size=chunk_size):
                if content:
                    fd.write(content)
        fd.close()
        zipfile = ZipFile(session.open('tvg.zip', 'r'))
        zipfile.extract('tvg.xml', session.path())
        zipfile.close()
        session.commit()
