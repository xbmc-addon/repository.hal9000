# -*- coding: utf-8 -*-

import datetime
import json
import urllib
import time

import xbmc
import xbmcvfs

import xbmcup.app
import xbmcup.gui
import xbmcup.system

from files import Files


COVER_MYMAGIVTV = xbmcup.system.fs('home://addons/plugin.video.mymagictv/resources/media/icons/mymagictv.png')
COVER_BACKWARD = xbmcup.system.fs('home://addons/plugin.video.mymagictv/resources/media/icons/backward.png')
COVER_FORWARD = xbmcup.system.fs('home://addons/plugin.video.mymagictv/resources/media/icons/forward.png')
COVER_FAVORITE = xbmcup.system.fs('home://addons/plugin.video.mymagictv/resources/media/icons/favorite.png')


class Index(xbmcup.app.Handler):
    def handle(self):
        login = self._auth()
        if login:
            try_num, groups = 20, None
            while try_num and groups is None:
                if try_num < 20:
                    xbmc.sleep(1000)
                try_num -= 1
                groups = Files(xbmc.translatePath('special://temp/mymagictv/m3u')).read('groups.json')
                if not groups and xbmcvfs.exists('special://temp/mymagictv/noauth.pid'):
                    xbmcvfs.delete('special://temp/mymagictv/noauth.pid')
                    xbmcup.gui.alert(xbmcup.app.lang[50004], title=u'myMAGicTV')
                    break
            else:
                if groups:
                    for i, group in json.loads(groups):
                        self.item(group, self.link('channels', gid=i), folder=True, cover=COVER_MYMAGIVTV)
        self.render(mode='list')

    def _auth(self):
        login = xbmcup.app.setting['login']
        password = xbmcup.app.setting['password']
        if not login or not password:
            xbmcup.gui.alert(xbmcup.app.lang[50003], title=u'myMAGicTV')
            login = xbmcup.gui.prompt(xbmcup.app.lang[50001])
            if not login:
                return
            password = xbmcup.gui.password(xbmcup.app.lang[50002])
            if not password:
                return
            xbmcup.app.setting['login'] = login
            xbmcup.app.setting['password'] = password
        return login


class Channels(xbmcup.app.Handler):
    def handle(self):
        channels = Files(xbmc.translatePath('special://temp/mymagictv/m3u')).read('%s.json' % self.argv['gid'])
        if channels:
            xmltv = Files(xbmc.translatePath('special://temp/mymagictv/xmltv'))
            for channel in json.loads(channels):
                name = channel['name']
                menu = None
                epg = 'channel.%s.json' % (channel['cid'] if channel.get('cid', '').isdigit() else urllib.quote_plus(name.lower().encode('utf8')).replace(' ', '_'))
                if channel['arc'] and xmltv.read(epg):
                    menu = [(xbmcup.app.lang[50401], self.resolve(
                        'archive',
                        name=channel['name'],
                        url=channel['url'],
                        arc=channel['arc'],
                        epg=epg
                    ))]
                    name = u'[COLOR FF00FF00]%s[/COLOR]' % name
                self.item(name, self.play(channel['url']), cover=channel['logo'], menu=menu)
        self.render(mode='thumb')


class Archive(xbmcup.app.Handler):
    def handle(self):
        epg = Files(xbmc.translatePath('special://temp/mymagictv/xmltv')).read(self.argv['epg'])
        if epg:
            now = int(time.strftime('%Y%m%d%H%M%S', time.gmtime(time.time())))
            arc = now - 60*60*self.argv['arc']
            select = []
            for programme in json.loads(epg):
                if now >= programme[0] > arc:
                    start = int(time.mktime(time.strptime(str(programme[0]), '%Y%m%d%H%M%S'))) - time.altzone
                    select.append((start, u'[COLOR FF00FF00]%s[/COLOR] %s' % (time.strftime('%H:%M', time.localtime(start)), programme[1])))
            if select:
                start = xbmcup.gui.select(self.argv['name'], select)
                if start:
                    return self.argv['url'] + '?time_start=%s' % (start + int(xbmcup.app.setting['timeshift']))


def run():
    plugin = xbmcup.app.Plugin()
    plugin.route(None, Index)
    plugin.route('channels', Channels)
    plugin.route('archive', Archive)
    plugin.run()
