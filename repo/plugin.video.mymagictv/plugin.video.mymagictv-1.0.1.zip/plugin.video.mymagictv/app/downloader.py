# -*- coding: utf-8 -*-

import re
import time
import json
import urllib
import xml.etree.ElementTree as ET
from zipfile import ZipFile
from contextlib import closing

import xbmc
import xbmcvfs
import requests

import xbmcup.app

from files import Files

RE = re.compile(r'''([^\s]+)\s*=\s*(?:"|')([^"']+)(?:"|')''')
RE_START_NUMBER = re.compile(r'^[0-9]+\..+')


class M3U:
    def __init__(self):
        self.files = Files(xbmc.translatePath('special://temp/mymagictv/m3u'))
        self.login = None
        self.password = None
        self.server = None
        self.quality = None
        self.lock = False
        self._notfound = 0

    def loop(self):
        if self.lock:
            return
        self.lock = True
        setting = xbmcup.app.Setting()
        login = setting['login']
        password = setting['password']
        server = setting['server']
        quality = setting['quality']
        if login and password and self.login != login or self.password != password or self.server != server or self.quality != quality:
            start = int(time.time())
            try:
                self.download('http://pl.mymagic.tv/srv/%s/%s/%s/%s/tv.m3u' % (server, quality, login, password))
            except Exception, e:
                xbmc.log(msg='[plugin.video.mymagictv] Exception: %s' % str(e), level=xbmc.LOGERROR)
            else:
                self.login = login
                self.password = password
                self.server = server
                self.quality = quality
                xbmc.log(msg='[plugin.video.mymagictv] M3U updated. Time: %s sec' % (int(time.time()) - start), level=xbmc.LOGNOTICE)
        self.lock = False

    def download(self, url):
        r = requests.get(url)
        if r.status_code == 403:
            open(xbmc.translatePath('special://temp/mymagictv/noauth.pid'), 'wb').close()
            raise Exception('Invalid login or password')
        channels = self.parse(r.content)
        groups = [(i + 1, x) for i, x in enumerate(sorted(channels.keys()))]
        session = self.files.transaction()
        session.write('groups.json', json.dumps(groups))
        for i, group in groups:
            session.write('%s.json' % i, json.dumps(sorted(channels[group], key=lambda r: r['name'])))
        session.commit()

    def parse(self, data):
        channels = {}
        cid, name, group, logo, arc = None, None, None, None, 0
        for line in data.split('\n'):
            line = line.strip()
            if not line:
                continue
            if line.startswith('#EXTM3U'):
                pass
            elif line.startswith('#EXTINF'):
                pairs = [x for x in [x.strip() for x in line.split(',')] if x]
                if len(pairs) > 1:
                    name = pairs[-1]
                    info = dict([(k, v) for k,v in [(k.strip(), v.strip()) for k,v in RE.findall(line)] if k and v])
                    logo = info.get('tvg-logo', 'http://prtl.mymagic.tv/images/logo_chanel/blank.png')
                    if 'arc-timeshift' in info and info['arc-timeshift'].isdigit():
                        arc = int(info['arc-timeshift'])
                    if 'group-title' in info:
                        # HACK: Remove numbers in begin string
                        group = info['group-title'].split('.', 1)[1] if RE_START_NUMBER.search(info['group-title']) else info['group-title']
                    if 'tvg-id' in info:
                        cid = info['tvg-id']
                    else:
                        self._notfound += 1
                        cid = 't%s' % self._notfound

            elif cid is None or group is None:
                continue

            else:
                channels.setdefault(group, []).append({'cid': cid, 'name': name, 'logo': logo, 'url': line, 'arc': arc})
                cid = None
                arc = 0
        return channels


class XMLTV:
    def __init__(self):
        self.files = Files(xbmc.translatePath('special://temp/mymagictv/xmltv'))
        self.last = 0
        self.lock = False

    def loop(self):
        if self.lock:
            return
        self.lock = True
        curtime = int(time.time())
        if self.last + 12*60*60 < curtime:
            try:
                self.download()
            except Exception, e:
                xbmc.log(msg='[plugin.video.mymagictv] Exception: %s' % str(e), level=xbmc.LOGERROR)
            else:
                self.last = int(time.time())
                xbmc.log(msg='[plugin.video.mymagictv] XMLTV updated. Time: %s sec' % (self.last - curtime), level=xbmc.LOGNOTICE)
        self.lock = False

    def download(self):
        session = self.files.transaction()
        fd = session.open('tvg.zip', 'w')
        with closing(requests.get('http://tvg.mymagic.tv/tvg.zip', stream=True)) as r:
            chunk_size = int(float(r.headers['content-length'])/100.0)
            if not chunk_size:
                chunk_size = 1
            for content in r.iter_content(chunk_size=chunk_size):
                if content:
                    fd.write(content)
        fd.close()
        zipfile = ZipFile(session.open('tvg.zip', 'r'))
        zipfile.extract('tvg.xml', session.path())
        zipfile.close()
        self.parse(session)
        session.commit()

    def parse(self, session):
        channels = {}
        fd = session.open('tvg.xml')
        for event, elem in ET.iterparse(fd, events=('end',)):
            if elem.tag == 'programme' and elem.attrib.get('channel') and elem.attrib.get('start') and elem.attrib.get('stop'):
                channels.setdefault(elem.attrib['channel'], {})
                channels[elem.attrib['channel']][int(elem.attrib['start'].replace(' +0000', ''))] = elem.find('title').text
        fd.close()
        for key, channel in channels.iteritems():
            session.write('channel.%s.json' % urllib.quote_plus(key.lower().encode('utf8')).replace(' ', '_'), json.dumps(sorted(channel.items(), key=lambda r: r[0], reverse=True)))


class Downloader:
    def __init__(self):
        if not xbmcvfs.exists('special://temp/mymagictv'):
            xbmcvfs.mkdirs('special://temp/mymagictv')

        self.m3u = M3U()
        self.xmltv = XMLTV()

    def loop(self):
        self.m3u.loop()
        self.xmltv.loop()
