# -*- coding: utf-8 -*-

from plugin.app.handlers import run

if __name__ == '__main__':
    run()
