# -*- coding: utf-8 -*-

import os

from xmltv import XMLTV
from m3u import M3U


class MyMagicTV:
    def __init__(self, basedir, login=None, password=None, server=None, quality=None):
        self._basedir = basedir
        self._login = login
        self._password = password
        self._server = server
        self._quality = quality
        if not os.path.isdir(basedir):
            os.mkdir(basedir)

    @property
    def xmltv(self):
        return XMLTV(self._basedir)

    @property
    def m3u(self):
        return M3U(self._basedir, self._login, self._password, self._server, self._quality)
