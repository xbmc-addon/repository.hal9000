# -*- coding: utf-8 -*-

import os
import re
import json

import xbmc
import requests

from files import Files


RE = re.compile(r'''([^\s]+)\s*=\s*(?:"|')([^"']+)(?:"|')''')
RE_START_NUMBER = re.compile(r'^[0-9]+\..+')


class M3U:
    def __init__(self, basedir, login, password, server, quality):
        self.files = Files(os.path.join(basedir, 'm3u', login))
        self._login = login
        self._password = password
        self._server = server
        self._quality = quality
        self._notfound = 0

    def make(self):
        session = self.files.transaction()
        url = 'http://pl.mymagic.tv/srv/%s/%s/%s/%s/tv.m3u' % (self._server, self._quality, self._login, self._password)
        r = requests.get(url)
        if r.status_code == 403:
            xbmc.log(msg='Invalid login or password', level=xbmc.LOGERROR)
        session.write('tv.m3u', r.content)
        channels = self._parse(session.read('tv.m3u').decode('utf8'))
        groups = [(i + 1, x) for i, x in enumerate(sorted(channels.keys()))]
        session.write('groups.json', json.dumps(groups))
        for i, group in groups:
            session.write('%s.json' % i, json.dumps(sorted(channels[group], key=lambda r: r['name'])))
        session.commit()

    def _parse(self, data):
        channels = {}
        cid, name, group, logo = None, None, None, None
        for line in data.split('\n'):
            line = line.strip()
            if not line:
                continue
            if line.startswith('#EXTM3U'):
                pass
            elif line.startswith('#EXTINF'):
                pairs = [x for x in [x.strip() for x in line.split(',')] if x]
                if len(pairs) > 1:
                    name = pairs[-1]
                    info = dict([(k, v) for k,v in [(k.strip(), v.strip()) for k,v in RE.findall(line)] if k and v])
                    logo = info.get('tvg-logo', 'http://prtl.mymagic.tv/images/logo_chanel/blank.png')
                    if 'group-title' in info:
                        # HACK: Remove numbers in begin string
                        group = info['group-title'].split('.', 1)[1] if RE_START_NUMBER.search(info['group-title']) else info['group-title']
                    if 'tvg-id' in info:
                        cid = info['tvg-id']
                    else:
                        self._notfound += 1
                        cid = 't%s' % self._notfound

            elif cid is None or group is None:
                continue

            else:
                channels.setdefault(group, []).append({'cid': cid, 'name': name, 'logo': logo, 'url': line})
                cid = None
        return channels
