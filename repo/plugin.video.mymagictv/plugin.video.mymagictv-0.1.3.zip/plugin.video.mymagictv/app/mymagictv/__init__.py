from kernel import MyMagicTV
from error import MyMagicTVError, MyMagicTVAuthError

__all__ = ['MyMagicTV', 'MyMagicTVError', 'MyMagicTVAuthError']
