# -*- coding: utf-8 -*-

__all__ = ['MyMagicTVError']


class MyMagicTVError(Exception):
    pass


class MyMagicTVAuthError(MyMagicTVError):
    pass
