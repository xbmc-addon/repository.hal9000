from kernel import MyMagicTV

__all__ = ['MyMagicTV']
