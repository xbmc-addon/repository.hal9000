# -*- coding: utf-8 -*-


class Progress:
    def __init__(self, total, callback, *args, **kwargs):
        self._total = float(total)/100.0
        self._callback = callback
        self._args = args
        self._kwargs = kwargs
        self._percent = 0

    def set(self, volume):
        percent = int(float(volume)/self._total) if self._total else 0
        if percent != self._percent:
            self._percent = percent
            if callable(self._callback):
                self._callback(percent, *self._args, **self._kwargs)
