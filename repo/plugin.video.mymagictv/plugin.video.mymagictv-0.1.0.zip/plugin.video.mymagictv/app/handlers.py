# -*- coding: utf-8 -*-

import json

import xbmc

import xbmcup.app
import xbmcup.gui
import xbmcup.system

from .mymagictv import MyMagicTV


COVER_MYMAGIVTV = xbmcup.system.fs('home://addons/plugin.video.mymagictv/resources/media/icons/mymagictv.png')
COVER_BACKWARD = xbmcup.system.fs('home://addons/plugin.video.mymagictv/resources/media/icons/backward.png')
COVER_FORWARD = xbmcup.system.fs('home://addons/plugin.video.mymagictv/resources/media/icons/forward.png')
COVER_FAVORITE = xbmcup.system.fs('home://addons/plugin.video.mymagictv/resources/media/icons/favorite.png')


class Index(xbmcup.app.Handler):
    def handle(self):
        login = self._auth()
        if login:
            try_num, groups = 20, None
            while try_num and groups is None:
                if try_num < 20:
                    xbmc.sleep(1000)
                try_num -= 1
                groups = MyMagicTV(xbmc.translatePath('special://temp/mymagictv'), login).m3u.files.read('groups.json')
            if groups:
                for i, group in json.loads(groups):
                    self.item(group, self.link('channels', gid=i), folder=True, cover=COVER_MYMAGIVTV)
        self.render(mode='list')

    def _auth(self):
        login = xbmcup.app.setting['login']
        password = xbmcup.app.setting['password']
        if not login or not password:
            xbmcup.gui.alert(xbmcup.app.lang[50003], title=u'myMAGicTV')
            login = xbmcup.gui.prompt(xbmcup.app.lang[50001])
            if not login:
                return
            password = xbmcup.gui.password(xbmcup.app.lang[50002])
            if not password:
                return
            xbmcup.app.setting['login'] = login
            xbmcup.app.setting['password'] = password
        return login


class Channels(xbmcup.app.Handler):
    def handle(self):
        login = xbmcup.app.setting['login']
        if login:
            channels = MyMagicTV(xbmc.translatePath('special://temp/mymagictv'), login).m3u.files.read('%s.json' % self.argv['gid'])
            if channels:
                for channel in json.loads(channels):
                    self.item(channel['name'], self.play(channel['url']), cover=channel['logo'])
        self.render(mode='thumb')


def run():
    plugin = xbmcup.app.Plugin()
    plugin.route(None, Index)
    plugin.route('channels', Channels)
    plugin.run()
