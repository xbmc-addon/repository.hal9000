# -*- coding: utf-8 -*-

import mymagictv


def progress(volume, action):
    print volume, action


#mymagictv.MyMagicTV('./data').xmltv.make(progress)
mymagictv.MyMagicTV('./data', 'hal9000', 'koditv', '0', '1').m3u.make()
