# -*- coding: utf-8 -*-

import xbmcup.app
import xbmcup.gui

from .tvclub import TVClub, TVClubError


class API:
    def api(self, method, params=None):
        login = xbmcup.app.setting['login']
        password = xbmcup.app.setting['password']
        if not login or not password:
            # TODO: Translate
            xbmcup.gui.alert(u'Authorization required', title=u'TVClub')
            login, password = self._auth()
            if not login:
                return

        while True:
            try:
                response = TVClub(login=login, password=password).api(method, params)
            except TVClubError, e:
                if e.code == -1:
                    # TODO: Translate
                    xbmcup.gui.alert(u'Invalid login or password', title=u'TVClub')
                    login, password = self._auth()
                    if not login:
                        return
                elif e.code == 13:  # protected code
                    # TODO: Translate
                    xbmcup.gui.alert(u'Неверный код', title=u'TVClub')
                    return
                elif e.code == 9:  # empty groups
                    raise
                else:
                    # TODO: Translate
                    xbmcup.gui.alert(u'%s (code %s)' % (e.msg, e.code), title='Error TVClub')
                    return
            except Exception, e:
                # TODO: Translate
                xbmcup.gui.alert(unicode(e), title='Unknown error')
                return
            else:
                xbmcup.app.setting['login'] = login
                xbmcup.app.setting['password'] = password
                return response

    def _auth(self):
        # TODO: Translate
        login = xbmcup.gui.prompt(u'Логин')
        if not login:
            return None, None
        # TODO: Translate
        password = xbmcup.gui.password(u'Пароль')
        if not password:
            return None, None
        return login, password
