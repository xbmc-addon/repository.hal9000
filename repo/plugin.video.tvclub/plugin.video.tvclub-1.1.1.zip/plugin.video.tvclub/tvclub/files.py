# -*- coding: utf-8 -*-

import os
import time
import shutil


class Files:
    def __init__(self, basedir):
        self.basedir = basedir
        if not os.path.isdir(self.basedir):
            os.mkdir(self.basedir)
        self.subdir = None

    # Transactions

    def start(self):
        self.clear()
        self.subdir = str(int(time.time()))
        if not os.path.isdir(os.path.join(self.basedir, self.subdir)):
            os.mkdir(os.path.join(self.basedir, self.subdir))

    def end(self):
        file(os.path.join(self.basedir, 'last.txt'), 'wb').write(self.subdir)
        self.subdir = None

    # File

    def open(self, filename, mode='r'):
        if mode == 'r':
            last = self._last()
            if last:
                return open(os.path.join(self.basedir, last, filename), 'rb')
        else:
            if self.subdir:
                return open(os.path.join(self.basedir, self.subdir, filename), 'wb')

    # Write
    def write(self, filename, data):
        fd = self.open(filename, 'w')
        if fd:
            fd.write(data)
            return True
        return False

    # Read

    def read(self, filename):
        fd = self.open(filename)
        if fd:
            data = fd.read()
            fd.close()
            return data

    def copy(self, filename, dst):
        last = self._last()
        if last:
            shutil.copyfile(os.path.join(self.basedir, last, filename), dst)
            return True
        return False

    def clear(self):
        last = self._last()
        if last:
            hour = int(time.time()) - 60*60
            dirnames = [x for x in sorted([int(x) for x in os.listdir(self.basedir) if x != 'last.txt']) if x < last and x < hour]
            for dirname in dirnames:
                for filename in os.listdir(os.path.join(self.basedir, str(dirname))):
                    os.remove(os.path.join(self.basedir, str(dirname), filename))
                os.rmdir(os.path.join(self.basedir, str(dirname)))

    def _last(self):
        filename = os.path.join(self.basedir, 'last.txt')
        if os.path.isfile(filename):
            return file(filename, 'rb').read().strip()
