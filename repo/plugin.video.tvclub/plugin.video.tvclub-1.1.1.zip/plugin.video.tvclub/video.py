# -*- coding: utf-8 -*-

from app.handlers import run

if __name__ == '__main__':
    run()
