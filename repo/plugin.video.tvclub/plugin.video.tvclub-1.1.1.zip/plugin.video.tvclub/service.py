# -*- coding: utf-8 -*-

import xbmc
import xbmcvfs

from app.epg import EPG


def main():
    if not xbmcvfs.exists('special://temp/tvclub/favorites'):
        xbmcvfs.mkdirs('special://temp/tvclub/favorites')

    epg = EPG()
    epg.loop()
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
        epg.loop()

if __name__ == '__main__':
    main()
