# -*- coding: utf-8 -*-

import json
import os
import time

from api import API
from error import TVClubError
from files import Files


class XMLTV:
    def __init__(self, basedir, login=None, password=None):
        self.files = Files(os.path.join(basedir, 'xmltv'))
        self._login = login
        self._password = password

    def make(self, start, end):
        Maker(self.files, self._login, self._password, start, end).make()


class Maker:
    def __init__(self, files, login, password, start, end):
        self.files = files
        self.api = API(login, password)
        self.start = start
        self.end = end
        self.fd = None

    def make(self):
        result = {
            'channels': [],
            'names': {}
        }
        groups = self.api.call('groups')
        self.files.start()
        self.fd = self.files.open('xmltv.xml', 'w')
        self.fd.write('<?xml version="1.0" encoding="UTF-8"?><tv generator-info-name="tvclub">')
        # TODO: translate - API отдает названия групп на русском и английском
        for group in sorted([{'gid': str(x['id']), 'name': x['name_ru']} for x in groups['groups']], key=lambda x: x['name']):
            try:
                protected, channels, names = self.channels(group['gid'])
            except TVClubError, e:
                if e.code != 9:
                    self.fd.close()
                    raise
            else:
                if not protected:
                    result['channels'].append((group['name'], channels))
                    result['names'].update(names)
        self.fd.write('</tv>')
        self.fd.close()
        self.files.write('channels.json', json.dumps(result))
        self.files.end()

    def channels(self, gid):
        page, protected, channels, names = 0, 0, [], {}
        while True:
            page += 1
            data = self.api.call('channels', {'gid': gid, 'limit': 200, 'page': page, 'sort': 3})
            for channel in data['channels']:
                channels.append(channel['info']['id'])
                names[channel['info']['id']] = channel['info']['name']
                self.fd.write((u'<channel id="%s"><display-name>%s</display-name><icon src="http://tvclub.us/logo/original/%s.png"/></channel>' % (
                    channel['info']['id'],
                    self.escape(channel['info']['name']),
                    channel['info']['id']
                )).encode('utf8'))
                if channel['info']['protected']:
                    protected = 1
            if data['info']['page'] == data['info']['pages']:
                break
        self.programme(gid)
        return protected, channels, names

    def programme(self, gid):
        current = self.start
        while current < self.end:
            page = 0
            while True:
                page += 1
                try:
                    epg = self.api.call('epg', {'time': current, 'period': 30, 'gid': gid, 'limit': 200, 'page': page})
                except TVClubError, e:
                    if e.code != 9:
                        self.fd.close()
                        raise
                    break
                else:
                    for channel in epg['epg']['channels']:
                        if 'epg' in channel and channel['epg']:
                            for programme in channel['epg']:
                                text = self.escape(programme['text']) if isinstance(programme['text'], basestring) else str(programme['text'])
                                description = self.escape(programme['description']) if 'description' in programme else u''
                                xml = u'<programme start="%s" stop="%s" channel="%s"><title>%s</title><desc>%s</desc></programme>' % (
                                    self.strftime(programme['start']),
                                    self.strftime(programme['end']),
                                    channel['id'],
                                    text,
                                    description
                                )
                                self.fd.write(xml.encode('utf8'))

                    if epg['info']['page'] == epg['info']['pages']:
                        break
            current += 30*60*60

    def escape(self, text):
        for f, t in ((u'&', u'&amp;'), (u'"', u'&quot;'), (u"'", u'&apos;'), (u'<', u'&lt;'), (u'>', u'&gt;')):
            text = text.replace(f, t)
        return text

    def strftime(self, sec):
        return time.strftime('%Y%m%d%H%M%S', time.gmtime(sec))
