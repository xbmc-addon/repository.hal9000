# -*- coding: utf-8 -*-

import json
import os

from api import API
from files import Files


class M3U:
    def __init__(self, basedir, login, password=None):
        self.files = Files(os.path.join(basedir, 'm3u', login))
        self._basedir = basedir
        self._login = login
        self._password = password
        self.api = API(login, password) if password else None
        self.channels = None
        self.fd = None

    def make(self):
        return Maker(self._basedir, self._login, self._password).make()


class Maker:
    def __init__(self, basedir, login, password):
        self.basedir = basedir
        self.files = Files(os.path.join(self.basedir, 'm3u', login))
        self.api = API(login, password)
        self.channels = None
        self.fd = None

    def make(self):
        channels = Files(os.path.join(self.basedir, 'xmltv')).read('channels.json')
        if not channels:
            return False
        self.channels = json.loads(channels)
        favorites = self.api.call('favorites')
        self.files.start()
        self.fd = self.files.open('epg.m3u', 'w')
        self.fd.write('#EXTM3U\n')
        if favorites['favorites']:
            # FIXME: Is it error in API? (dict or list)
            if isinstance(favorites['favorites'], dict):
                favorites = [v for k, v in sorted(favorites['favorites'].items(), key=lambda x: int(x[0]))]
            else:
                favorites = favorites['favorites'][:]
            # TODO: translate - добавить "Favorites"
            self.render(u'Избранное', [x for x in favorites if str(x) in self.channels['names']])
        for group in self.channels['channels']:
            self.render(group[0], group[1])
        self.fd.close()
        self.files.end()
        return True

    def render(self, group, channels):
        if not channels:
            return
        self.make_channel(channels[0], group)
        for cid in channels[1:]:
            self.make_channel(cid)

    def make_channel(self, cid, group=None):
        name = self.channels['names'][str(cid)]
        if group:
            text = u'#EXTINF:-1 tvg-id="%s" tvg-name="%s" group-title="%s",%s\n' % (
                cid,
                self.escape(name).replace(u' ', u'_'),
                group.replace(u'"', u'&quot;'),
                name.replace(u'"', u'&quot;')
            )
        else:
            text = u'#EXTINF:-1 tvg-id="%s" tvg-name="%s",%s\n' % (
                cid,
                self.escape(name).replace(u' ', u'_'),
                name.replace(u'"', u'&quot;')
            )
        text += u'http://tvclub.us/play/%s/%s\n' % (self.api.token, cid)
        self.fd.write(text.encode('utf8'))

    def escape(self, text):
        for f, t in ((u'&', u'&amp;'), (u'"', u'&quot;'), (u"'", u'&apos;'), (u'<', u'&lt;'), (u'>', u'&gt;')):
            text = text.replace(f, t)
        return text
