# -*- coding: utf-8 -*-

import json

import xbmcvfs
import xbmcgui

import xbmcup.gui

from api import API, TVClubError


class Favorites(API):
    def change(self, argv):
        if argv and 'favorites' in argv:
            if argv['favorites']['action'] == 'remove':
                self.remove(argv['favorites']['cid'])
            else:
                self.set_favorites(
                    argv['favorites']['cid'],
                    argv['favorites']['name'],
                    argv['favorites']['protected'],
                    argv['favorites']['action']
                )

    def fetch(self):
        favorites = self.api('favorites')
        if favorites:
            # It's error in API (dict or list)
            if isinstance(favorites['favorites'], dict):
                return [v for k, v in sorted(favorites['favorites'].items(), key=lambda x: int(x[0]))]
            return favorites['favorites'][:]

    def get(self):
        favorites = self.fetch()
        if favorites is None:
            return
        if not favorites:
            return []
        try_num = 0
        while True:
            names = self.load()

            result = []
            for cid in favorites:
                if str(cid) not in names:
                    break
                result.append((cid, names[str(cid)][0], names[str(cid)][1]))
            else:
                return result

            try_num += 1
            if try_num == 2:
                return

            # fetching channels
            progress = xbmcgui.DialogProgressBG()
            # TODO: Translate
            progress.create(u'TVClub', u'Fetching channels...')
            groups = self.api('groups')
            if not groups:
                progress.close()
                return
            names = {}
            for i, group in enumerate(groups['groups']):
                # TODO: Translate
                progress.update(message=u'Fetching group %s' % group['name_ru'])
                page = 0
                while True:
                    page += 1
                    try:
                        channels = self.api('channels', {'gid': group['id'], 'limit': 200, 'page': page})
                    except TVClubError, e:
                        if e.code == 9:  # empty group
                            break
                        raise
                    if not channels:
                        progress.close()
                        return
                    names.update(dict([(str(x['info']['id']), [x['info']['name'], x['info']['protected']]) for x in channels['channels'] if x['info']['id'] in favorites]))
                    if channels['info']['page'] == channels['info']['pages']:
                        break
                progress.update(int(float(i) / (float(len(groups['groups'])) / 100.0)))
            progress.close()
            self.save(names)

    def set_favorites(self, cid, name, protected, action):
        favorites = self.get()
        if favorites is None:
            return
        pos = 1
        favorites = [x for x in favorites if x[0] != cid]
        if favorites:
            items = [
                ('first', u'[COLOR=FF669966]В начало списка[/COLOR]'),  # TODO: Translate
                ('last', u'[COLOR=FF669966]В конец списка[/COLOR]')  # TODO: Translate
            ]
            items.extend([(i + 2, x[1]) for i, x in enumerate(favorites)])
            # TODO: Translate
            pos = xbmcup.gui.select(u'Add after:' if action == 'add' else u'Move to:', items)
            if not pos:
                return
        if self.api('set_favorites', {'cid': cid, 'pos': pos}):
            names = self.load()
            names[str(cid)] = [name, protected]
            self.save(names)

    def remove(self, cid):
        if self.api('set_favorites', {'cid': cid, 'pos': 'del'}):
            names = self.load()
            try:
                del names[str(cid)]
            except KeyError:
                pass
            else:
                self.save(names)

    def load(self):
        try:
            fd = xbmcvfs.File('special://temp/tvclub/favorites/names.json')
        except:
            return {}
        else:
            names = json.loads(fd.read())
            fd.close()
            return names

    def save(self, names):
        fd = xbmcvfs.File('special://temp/tvclub/favorites/names.json', 'w')
        fd.write(json.dumps(names))
        fd.close()