# -*- coding: utf-8 -*-


class TVClubError(Exception):
    def __init__(self, code, msg):
        self.code = code
        self.msg = msg
        Exception.__init__(self, str(self))

    def __str__(self):
        return "TVClubError(code = '%s', msg = '%s')" % (self.code, self.msg)
