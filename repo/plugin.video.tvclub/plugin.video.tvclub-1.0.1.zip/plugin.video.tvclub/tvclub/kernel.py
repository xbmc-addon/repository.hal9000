# -*- coding: utf-8 -*-

import os

from api import API
from xmltv import XMLTV
from m3u import M3U


class TVClub:
    def __init__(self, basedir=None, login=None, password=None):
        self._login = login
        self._password = password
        self._basedir = basedir
        if basedir and not os.path.isdir(basedir):
            os.mkdir(basedir)

    @property
    def xmltv(self):
        return XMLTV(self._basedir, self._login, self._password)

    @property
    def m3u(self):
        return M3U(self._basedir, self._login, self._password)

    def api(self, method, params):
        return API(self._login, self._password).call(method, params)
