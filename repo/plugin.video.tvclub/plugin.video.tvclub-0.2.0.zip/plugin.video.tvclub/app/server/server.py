# -*- coding: utf-8 -*-

import threading
from wsgiref.simple_server import make_server, WSGIRequestHandler

from bottle import Bottle, ServerAdapter, response, redirect, abort

import xbmc
import xbmcaddon
from tvclub import TVClub, TVClubError

from xmltv import XMLTV
from m3u import M3U
from utils import FileSystem


class App:
    def __init__(self):
        FileSystem().mkdir('/tvclub/build')
        self.lock = dict(xmltv=False, m3u=False)
        self.tasks = dict(xmltv=XMLTV(), m3u=M3U())

    def loop(self):
        for task in ('xmltv', 'm3u'):
            if not self.lock[task]:
                self.lock[task] = True
                self.tasks[task].loop()
                self.lock[task] = False

    def set_port(self, port):
        self.tasks['m3u'].port = port


class HTTP:
    def __init__(self):
        self.fs = FileSystem()
        self.api = TVClub()

    def resolve(self, cid):
        try:
            live = self.api.live(cid)
        except TVClubError, e:
            level = xbmc.LOGWARNING if e.code == 4 else xbmc.LOGERROR
            xbmc.log(msg='[plugin.video.tvclub] [server.App] TVClub API (code %s): %s' % (e.code, e.msg), level=level)
            abort(401 if e.code == 4 else 500, e.msg)
        except Exception, e:
            xbmc.log(msg='[plugin.video.tvclub] [server.App] Exception: %s' % (str(e),), level=xbmc.LOGERROR)
            abort(500, str(e))
        else:
            redirect(live['live']['url'], 302)

    def xmltv(self):
        data = self.fs.load('/tvclub/xmltv.xml')
        if data:
            response.content_type = 'text/xml; charset=utf-8'
            return data
        else:
            abort(404, 'Not Found')

    def m3u(self):
        data = self.fs.load('/tvclub/playlist.m3u')
        if data:
            response.content_type = 'application/x-mpegURL; charset=utf-8'
            return data
        else:
            abort(404, 'Not Found')


class Server:
    def __init__(self):
        self.server = None
        self.port = None
        self.app = App()
        self.http = HTTP()

    def loop(self):
        try:
            port = int(xbmcaddon.Addon(id='plugin.video.tvclub').getSetting('port'))
        except Exception, e:
            xbmc.log(msg='[plugin.video.tvclub] [server] ' + str(e), level=xbmc.LOGWARNING)
        else:
            if self.port != port:
                self.app.set_port(port)
                self.port = port
                self.stop()
                self.run()
        self.app.loop()

    def run(self):
        threading.Thread(target=self._run).start()

    def _run(self):
        app = Bottle()
        app.route('/xmltv', callback=self.http.xmltv)
        app.route('/m3u', callback=self.http.m3u)
        app.route('/resolve/<cid>', callback=self.http.resolve)
        self.server = BottleServer(host='localhost', port=self.port)
        try:
            app.run(server=self.server)
        except Exception, e:
            xbmc.log(msg='[plugin.video.tvclub] [server] ' + str(e), level=xbmc.LOGERROR)
        xbmc.log(msg='[plugin.video.tvclub] [server] Server stopped', level=xbmc.LOGERROR)
        self.server = None

    def stop(self):
        if self.server:
            self.server.stop()
            while self.server:
                xbmc.sleep(300)


# BOTTLE WEB SERVER

class QuietHandler(WSGIRequestHandler):
    def log_request(*args, **kwargs):
        pass


class BottleServer(ServerAdapter):
    server = None

    def run(self, handler):
        if self.quiet:
            self.options['handler_class'] = QuietHandler
        self.server = make_server(self.host, self.port, handler, **self.options)
        self.server.serve_forever()

    def stop(self):
        self.server.shutdown()
