# -*- coding: utf-8 -*-

import json

import xbmc
import xbmcvfs

from handler import Handler
from utils import FileSystem, escape


class Task:
    def __init__(self, port):
        self.port = port
        self.fs = FileSystem()
        self.channels = json.loads(self.fs.load('/tvclub/channels.json', '{}'))
        self.fd = xbmcvfs.File('special://temp/tvclub/playlist.temp', 'w')

    def run(self):
        if self.channels:
            self.fd.write('#EXTM3U\n')
            # сразу удалить те каналы, которых нет в data['channels']
            favorites = []
            #favorites = ['xxx', 'yyy', 'zzz']  # TODO: test

            if favorites:
                favorites = [(cid, self.channels['names'][cid]) for cid in favorites if cid in self.channels['names']]
                if favorites:
                    # TODO: translate - добавить "Favorites"
                    self.render(favorites, u'Избранное')
            for gid, name in self.channels['groups']:
                channels = [(cid, self.channels['names'][cid]) for cid in self.channels['cids'].get(gid, []) if cid not in favorites]
                if channels:
                    self.render(channels, name)
        self.stop()

    def render(self, channels, group):
        self.make_channel(channels[0][0], channels[0][1], group)
        for cid, name in channels[1:]:
            self.make_channel(cid, name)

    def make_channel(self, cid, name, group=None):
        if group:
            text = u'#EXTINF:-1 tvg-id="%s" tvg-name="%s" group-title="%s",%s\n' % (
                cid,
                escape(name).replace(u' ', u'_'),
                group.replace(u'"', u'&quot;'),
                name.replace(u'"', u'&quot;')
            )
        else:
            text = u'#EXTINF:-1 tvg-id="%s" tvg-name="%s",%s\n' % (
                cid,
                escape(name).replace(u' ', u'_'),
                name.replace(u'"', u'&quot;')
            )
        text += u'http://localhost:%s/resolve/%s\n' % (self.port, cid)
        self.fd.write(text.encode('utf8'))

    def stop(self):
        if self.fd:
            self.fd.close()


class M3U(Handler):
    def __init__(self):
        self.task = None
        self.port = None
        # TODO: test
        FileSystem().save('/tvclub/build/1', '1')

    def handle(self):
        files = xbmcvfs.listdir('special://temp/tvclub/build')[1]
        if files:
            self.task = Task(self.port)
            self.task.run()
            self.task = None
            xbmcvfs.rename('special://temp/tvclub/playlist.temp', 'special://temp/tvclub/playlist.m3u')
            for filename in files:
                xbmcvfs.delete('special://temp/tvclub/build/' + filename)
            xbmc.log(msg='[plugin.video.tvclub] [server.M3U] M3U-playlist updated', level=xbmc.LOGNOTICE)

    def fail(self):
        if self.task:
            self.task.stop()
