# -*- coding: utf-8 -*-

import json
import time
import threading

import xbmc
import xbmcvfs
from tvclub import TVClub, TVClubError

from handler import Handler
from utils import FileSystem, escape, strftime

THREAD = 20


class Task:
    def __init__(self, start, end):
        self.time_start = int(time.time())
        self.time_end = None
        self.start = start
        self.end = end
        self.fd = xbmcvfs.File('special://temp/tvclub/xmltv.temp', 'w')
        self.api = TVClub()
        self.channels = {
            'groups': [],
            'cids': {},
            'names': {}
        }
        self.error = None
        self.buffer = []
        self.not_found = []

    def run(self):
        self.fd.write('<?xml version="1.0" encoding="UTF-8"?><tv generator-info-name="plugin.video.tvclub">')
        for group in self.api.groups()['groups']:
            gid = str(group['id'])
            # TODO: translate - API отдает названия групп на русском и английском
            self.channels['groups'].append((gid, group['name_ru']))
            self.channels['cids'][gid] = []
            self.get_channels(gid)
        self.fd.write('</tv>')
        self.time_end = int(time.time())
        self.stop()
        if self.not_found:
            msg = "[plugin.video.tvclub] [server.XMLTV] TVClub API (code 9): Channels not found or not allowed: %s" % (
                str(self.not_found),
            )
            xbmc.log(msg=msg, level=xbmc.LOGWARNING)
        return len(self.not_found), len(self.channels['names']), self.time_end - self.time_start

    def get_channels(self, gid):
        page = 0
        while True:
            page += 1
            channels = self.api.channels(gid, limit=200, page=page, sort=3)
            for channel in channels['channels']:
                cid = str(channel['info']['id'])
                self.channels['cids'][gid].append(cid)
                self.channels['names'][cid] = channel['info']['name']
                self.fd.write('<channel id="%s"><display-name>%s</display-name><icon src="%s"/></channel>' % (
                    channel['info']['id'],
                    escape(channel['info']['name']).encode('utf8'),
                    self.api.logo(cid, 490)
                ))
            if channels['info']['page'] == channels['info']['pages']:
                break

        if self.channels['cids'][gid]:
            self.get_epg(self.channels['cids'][gid])

    def get_epg(self, cids):
        while cids:
            query = cids[0:THREAD]
            cids = cids[THREAD:]
            pool = []
            for cid in query:
                pool.append(threading.Thread(target=self.fetch_epg, args=(cid,)))
            for t in pool:
                t.start()
            for t in pool:
                t.join()
            if self.error:
                raise self.error
            for cid, programme in self.buffer:
                self.make_programme(cid, programme)
            self.buffer = []

    def fetch_epg(self, cid):
        current = self.start
        while current < self.end:
            page = 0
            while True:
                page += 1
                try:
                    epg = self.api.epg(time=current, period=30, channels=[cid], limit=200, page=page)
                except TVClubError, e:
                    if e.code == 9:
                        self.not_found.append(cid)
                    else:
                        self.error = e
                    return
                else:
                    for channel in epg['epg']['channels']:
                        if 'epg' in channel and channel['epg']:
                            for programme in channel['epg']:
                                self.buffer.append((channel['id'], programme))
                    if epg['info']['page'] == epg['info']['pages']:
                        break
            current += 30*60*60

    def make_programme(self, cid, programme):
        text = escape(programme['text']) if isinstance(programme['text'], basestring) else str(programme['text'])
        description = escape(programme['description']) if 'description' in programme else u''
        xml = u'<programme start="%s" stop="%s" channel="%s"><title>%s</title><desc>%s</desc></programme>' % (
            strftime(programme['start']),
            strftime(programme['end']),
            cid,
            text,
            description
        )
        self.fd.write(xml.encode('utf8'))

    def stop(self):
        if self.fd:
            self.fd.close()


class XMLTV(Handler):
    def __init__(self):
        self.fs = FileSystem()
        self.task = None
        # TODO: test
        #self.fs.save('/tvclub/cache.deadline.txt', str(0))

    def handle(self):
        deadline = int(self.fs.load('/tvclub/cache.deadline.txt', 0))
        if deadline and int(time.time()) < deadline:
            return

        # TODO: перенести период в настройки
        start = int(time.time()) - 24*60*60  # -1 day
        end = int(time.time()) + 24*60*60  # +1 day

        self.task = Task(start, end)
        not_found, total, seconds = self.task.run()
        self.fs.save('/tvclub/channels.json.temp', json.dumps(self.task.channels))
        self.task = None
        xbmcvfs.rename('special://temp/tvclub/xmltv.temp', 'special://temp/tvclub/xmltv.xml')
        xbmcvfs.rename('special://temp/tvclub/channels.json.temp', 'special://temp/tvclub/channels.json')
        self.fs.save('/tvclub/build/' + str(int(time.time())), '1')
        self.fs.save('/tvclub/cache.deadline.txt', str(int(time.time()) + 3*60*60))  # 3 hours
        found = total - not_found
        xbmc.log(msg='[plugin.video.tvclub] [server.XMLTV] EPG updated. Channels: %s/%s. Time: %s sec' % (found, total, seconds), level=xbmc.LOGNOTICE)

    def fail(self):
        if self.task:
            self.task.stop()
        self.fs.save('/tvclub/cache.deadline.txt', str(int(time.time()) + 5*60))  # 5 minutes
