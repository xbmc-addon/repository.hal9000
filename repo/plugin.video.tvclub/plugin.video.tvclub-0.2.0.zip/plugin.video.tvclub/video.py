# -*- coding: utf-8 -*-

import xbmcup.app

from app.client import Index, Groups, Channels, Live


plugin = xbmcup.app.Plugin()

plugin.route(None, Index)
plugin.route('groups', Groups)
plugin.route('channels', Channels)
plugin.route('live', Live)

plugin.run()
