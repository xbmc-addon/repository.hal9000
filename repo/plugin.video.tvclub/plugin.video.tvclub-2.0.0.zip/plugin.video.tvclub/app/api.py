# -*- coding: utf-8 -*-

import hashlib

import requests

from error import TVClubError

VERSION = '0.8'


class API:
    def __init__(self, login, password):
        self.token = hashlib.md5(login + hashlib.md5(password).hexdigest()).hexdigest() if login and password else None

    def call(self, method, params=None):
        if not self.token:
            raise TVClubError(4, 'API Exception: Empty login or password')
        params = dict([(k, v) for k, v in params.iteritems() if v is not None]) if params else {}
        params['token'] = self.token
        try:
            r = requests.get('http://api.iptv.so/' + VERSION + '/json/' + method, params)
        except requests.exceptions.RequestException, e:
            raise TVClubError(e.response.status_code if e.response else 0, 'Request Exception: ' + str(e))
        else:
            response = r.json()
            if 'error' in response:
                if response['error']['code'] in (4, 5, 6, 16):
                    raise TVClubError(4, 'API Exception: Invalid login or password')
                else:
                    raise TVClubError(response['error']['code'], 'API Exception: %s' % response['error']['msg'])
            return response
