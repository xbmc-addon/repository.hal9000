# -*- coding: utf-8 -*-

import re
import time
import json
import hashlib
import os.path
import shutil
import threading

import xbmc
import xbmcvfs

import requests
import xbmcup.app

from files import Files
from api import API
from error import TVClubError

RE = re.compile(r'''([^\s]+)\s*=\s*(?:"|')([^"']+)(?:"|')''')

ALL_CHANNELS = u'Все каналы'.encode('utf8')
PROTECTED = u'Взрослые'.encode('utf8')

class M3U:
    def __init__(self):
        if not xbmcvfs.exists('special://temp/tvclub/flush'):
            xbmcvfs.mkdirs('special://temp/tvclub/flush')
        self.files = Files(xbmc.translatePath('special://temp/tvclub/m3u'))
        self._login = None
        self._password = None
        self._path = None
        self.login = None
        self.password = None
        self.path = None
        self.last = 0
        self.flush = None
        self._error = False

    def loop(self):
        self.flush = sorted([int(x) for x in xbmcvfs.listdir('special://temp/tvclub/flush')[1]], reverse=True)
        setting = xbmcup.app.Setting()
        self._login = setting['login']
        self._password = setting['password']
        self._path = setting['path']
        if setting['epg'] != '1' or not self._path or not os.path.isdir(self._path):
            self._path = None
        if self.flush or self.login != self._login or self.password != self._password or self.path != self._path or int(time.time()) > self.last + 3*60*60:
            start = int(time.time())
            try:
                self.run()
            except TVClubError, e:
                self.error(e.code, e.msg)
            except Exception, e:
                self.error(0, 'Unknown Exception: %s' % str(e))
                raise
            else:
                xbmc.log(msg='[plugin.video.tvclub] Channels updated. Time: %s sec' % (int(time.time()) - start), level=xbmc.LOGNOTICE)
                if self._path:
                    try:
                        shutil.copyfile(os.path.join(self.files.path(), 'playlist.m3u'), os.path.join(self._path, 'tvclub.playlist.m3u'))
                    except Exception, e:
                        xbmc.log(msg='[plugin.video.tvclub] Unknown Exception: %s' % str(e), level=xbmc.LOGERROR)
                    else:
                        xbmc.log(msg='[plugin.video.tvclub] M3U updated', level=xbmc.LOGNOTICE)
                self.finish()

    def run(self):
        groups, channels = self.parse(self.favorites(), self.m3u())
        session = self.files.transaction()
        session.write('groups.json', json.dumps(groups))
        m3u = session.open('playlist.m3u', 'w') if self._path else None
        m3u.write('#EXTM3U cache=500 nameaskey=1 tvg-logo=http://tvclub.us/logo/original/%tvg%.png\n')
        for group in groups:
            dump = sorted(channels[group[1]], key=lambda r: r['name']) if group[0] != 1 else channels[group[1]]
            if m3u and group[0] != 2:
                if group[1] == 'favorites':
                    group[1] = u'Избранное'.encode('utf8') if xbmc.getLanguage(xbmc.ISO_639_1) == 'ru' else 'Favorites'
                for channel in dump:
                    line = '#EXTINF:-1 tvg-id="%s" tvg-name="%s" group-title="%s",%s\n%s\n' % (
                        channel['cid'],
                        channel['name'].replace('"', '&quot;').replace(' ', '_'),
                        group[1],
                        channel['name'],
                        channel['url']
                    )
                    m3u.write(line)
            session.write('%s.json' % group[0], json.dumps(dump))
        if m3u:
            m3u.close()
        session.commit()

    def parse(self, favorites, m3u):
        cid, name, group, all_channels, channels = None, None, None, {}, {}
        for line in m3u.split('\n'):
            line = line.strip()
            if not line:
                continue
            if line.startswith('#EXTM3U') or line.startswith('#EXTGRP'):
                pass
            elif line.startswith('#EXTINF'):
                pairs = [x for x in [x.strip() for x in line.split(',')] if x]
                if len(pairs) > 1:
                    name = pairs[-1]
                    info = dict([(k, v) for k,v in [(k.strip(), v.strip()) for k,v in RE.findall(line)] if k and v])
                    if 'group-title' in info:
                        group = info['group-title']
                    if 'tvg-id' in info and info['tvg-id'].isdigit():
                        cid = int(info['tvg-id'])

            elif cid is None or group is None:
                continue

            else:
                protected = bool(group == PROTECTED)
                if not protected:
                    all_channels[cid] = {'cid': cid, 'name': name, 'url': line, 'protected': protected}
                channels.setdefault(group, [])
                channels[group].append({'cid': cid, 'name': name, 'url': line, 'protected': protected})
                cid = None

        groups = [[i + 3, x, len(channels[x])] for i, x in enumerate(sorted(channels.keys()))]

        channels['favorites'] = [all_channels[cid] for cid in favorites if cid in all_channels]
        channels[ALL_CHANNELS] = all_channels.values()

        groups.insert(0, [2, ALL_CHANNELS, len(channels[ALL_CHANNELS])])
        groups.insert(0, [1, 'favorites', len(channels['favorites'])])

        return groups, channels

    def favorites(self):
        response = API(self._login, self._password).call('favorites')
        if isinstance(response['favorites'], dict):
            return [v for k, v in sorted(response['favorites'].items(), key=lambda x: int(x[0]))]
        return response['favorites'][:]

    def m3u(self):
        content = requests.get('http://tvclub.us/play/%s' % hashlib.md5(self._login + hashlib.md5(self._password).hexdigest()).hexdigest()).content
        if content == 'Error auth':
            raise TVClubError(4, 'PlaylistError: Invalid login or password')
        return content

    def error(self, code, msg):
        if code == 4:
            self.auth()
            xbmc.log(msg='[plugin.video.tvclub] %s' % msg, level=xbmc.LOGERROR)
            self.finish()
        elif not self._error:
            self.auth(remove=True)
            xbmc.log(msg='[plugin.video.tvclub] %s' % msg, level=xbmc.LOGERROR)

    def auth(self, remove=False):
        if remove:
            if xbmcvfs.exists('special://temp/tvclub/noauth.pid'):
                xbmcvfs.delete('special://temp/tvclub/noauth.pid')
        else:
            f = xbmcvfs.File('special://temp/tvclub/noauth.pid', 'w')
            f.write(str(time.time()))
            f.close()

    def finish(self):
        if self.flush:
            [xbmcvfs.delete('special://temp/tvclub/flush/%s' % x) for x in self.flush]
            self.flush = None
        self.login = self._login
        self.password = self._password
        self.path = self._path
        self.last = int(time.time())


class XMLTV:
    def __init__(self):
        self.files = Files(xbmc.translatePath('special://temp/tvclub/xmltv'))
        self._login = None
        self._password = None
        self._path = None
        self.login = None
        self.password = None
        self.path = None
        self.last = 0
        self.api = None
        self.session = None
        self.records = {}
        self.names = {}
        self.archive = 0

    def loop(self):
        setting = xbmcup.app.Setting()
        self._login = setting['login']
        self._password = setting['password']
        self._path = setting['path']
        if setting['epg'] != '1' or not self._path or not os.path.isdir(self._path):
            self._path = None
        if self.login != self._login or self.password != self._password or self.path != self._path or int(time.time()) > self.last + 12*60*60:
            self.api = API(self._login, self._password)
            start = int(time.time())
            try:
                self.run()
            except TVClubError, e:
                if e.code == 4:
                    self.finish()
                xbmc.log(msg='[plugin.video.tvclub] %s' % e.msg, level=xbmc.LOGERROR)
            except Exception, e:
                xbmc.log(msg='[plugin.video.tvclub] Unknown Exception: %s' % str(e), level=xbmc.LOGERROR)
                raise
            else:
                xbmc.log(msg='[plugin.video.tvclub] EPG updated. Time: %s sec' % (int(time.time()) - start), level=xbmc.LOGNOTICE)
                if self._path:
                    try:
                        shutil.copyfile(os.path.join(self.files.path(), 'xmltv.xml'), os.path.join(self._path, 'tvclub.xmltv.xml'))
                    except Exception, e:
                        xbmc.log(msg='[plugin.video.tvclub] Unknown Exception: %s' % str(e), level=xbmc.LOGERROR)
                    else:
                        xbmc.log(msg='[plugin.video.tvclub] XMLTV updated', level=xbmc.LOGNOTICE)
                self.finish()

    def run(self):
        response = self.api.call('groups')
        self.records = {}
        self.names = {}
        self.archive = 0
        self.session = self.files.transaction()
        gids = [group['id'] for group in response['groups']]
        self.thread(self.channels, gids)
        self.archive = max(self.records.values())
        self.session.write('records.json', json.dumps(self.records))
        self.thread(self.epg, gids)
        self.session.write('channels.json', json.dumps(self.names))
        if self._path:
            self.xmltv()
        self.session.commit()

    def thread(self, function, gids):
        pool = [threading.Thread(target=self.fetch, args=(function, gid)) for gid in gids]
        [p.start() for p in pool]
        [p.join() for p in pool]

    def fetch(self, function, gid):
        try:
            function(gid)
        except TVClubError, e:
            if e.code != 9:
                xbmc.log(msg='[plugin.video.tvclub] %s (group %s)' % (e.msg, gid), level=xbmc.LOGERROR)
        except Exception, e:
            xbmc.log(msg='[plugin.video.tvclub] Unknown Exception: %s (group %s)' % (str(e), gid), level=xbmc.LOGERROR)

    def channels(self, gid):
        page = 0
        while True:
            page += 1
            response = self.api.call('channels', {'gid': gid, 'limit': 200, 'page': page})
            for channel in response['channels']:
                self.names[channel['info']['id']] = channel['info']['name']
                if channel['info']['records']:
                    self.records[channel['info']['id']] = channel['info']['records']
            if response['info']['page'] == response['info']['pages']:
                break

    def epg(self, gid):
        epg = {}
        if not self.archive:
            self.archive = 24
        current = int(time.time()) - self.archive*60*60
        end = int(time.time()) + 32*60*60
        while current < end:
            page = 0
            while True:
                page += 1
                response = self.api.call('epg', {'gid': gid, 'time': current, 'period': 30, 'limit': 200, 'page': page})
                for channel in response['epg']['channels']:
                    for programme in channel['epg']:
                        epg.setdefault(channel['id'], [])
                        epg[channel['id']].append((
                            programme['start'],
                            programme['end'],
                            programme['text'],
                            programme['description'] if 'description' in programme else u''
                        ))
                if response['info']['page'] == response['info']['pages']:
                    break
            current += 30*60*60
        for cid, programme in epg.iteritems():
            self.session.write('epg.%s.json' % cid, json.dumps(sorted(programme, key=lambda x: x[0], reverse=True)))

    def xmltv(self):
        day = int(time.time()) - 24*60*60
        channels = json.loads(self.session.read('channels.json'))
        fd = self.session.open('xmltv.xml', 'w')
        fd.write('<?xml version="1.0" encoding="UTF-8"?><tv generator-info-name="tvclub">')
        for cid, name in channels.iteritems():
            fd.write((u'<channel id="%s"><display-name>%s</display-name><icon src="http://tvclub.us/logo/original/%s.png"/></channel>' % (
                    cid,
                    self.escape(name),
                    cid
                )).encode('utf8'))
            epg = self.session.read('epg.%s.json' % cid)
            if epg:
                for start, end, name, description in json.loads(epg):
                    if start > day:
                        fd.write((u'<programme start="%s" stop="%s" channel="%s"><title>%s</title><desc>%s</desc></programme>' % (
                            self.strftime(start),
                            self.strftime(end),
                            cid,
                            self.escape(name) if isinstance(name, basestring) else str(name),
                            self.escape(description)
                        )).encode('utf8'))
        fd.write('</tv>')
        fd.close()

    def escape(self, text):
        for f, t in ((u'&', u'&amp;'), (u'"', u'&quot;'), (u"'", u'&apos;'), (u'<', u'&lt;'), (u'>', u'&gt;')):
            text = text.replace(f, t)
        return text

    def strftime(self, sec):
        return time.strftime('%Y%m%d%H%M%S', time.gmtime(sec))

    def finish(self):
        self.login = self._login
        self.password = self._password
        self.path = self._path
        self.last = int(time.time())



class Downloader:
    def __init__(self):
        if not xbmcvfs.exists('special://temp/tvclub'):
            xbmcvfs.mkdirs('special://temp/tvclub')

        self.m3u = M3U()
        self.xmltv = XMLTV()

    def loop(self):
        self.m3u.loop()
        self.xmltv.loop()
