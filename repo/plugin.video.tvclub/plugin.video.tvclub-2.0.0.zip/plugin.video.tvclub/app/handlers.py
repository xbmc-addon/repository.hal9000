# -*- coding: utf-8 -*-

import datetime
import json
import urllib
import time

import xbmc
import xbmcvfs

import xbmcup.app
import xbmcup.gui
import xbmcup.system

from files import Files
from api import API as BaseAPI
from error import TVClubError

COVER = xbmcup.system.fs('home://addons/plugin.video.tvclub/resources/icon.png')


class API:
    def api(self, method, params):
        try:
            result = BaseAPI(xbmcup.app.setting['login'], xbmcup.app.setting['password']).call(method, params)
        except TVClubError, e:
            if e.code == 4:
                xbmcup.gui.alert(xbmcup.app.lang[50502], title=u'TVClub')  # Invalid auth
                raise
            elif e.code == 13:
                xbmcup.gui.alert(xbmcup.app.lang[50503], title=u'TVClub')  # Invalid protected code
                return
            else:
                xbmcup.gui.alert(u'%s (code %s)' % (e.msg, e.code), title=xbmcup.app.lang[50501])
                raise
        except Exception, e:
            xbmcup.gui.alert(unicode(e), title=xbmcup.app.lang[50504])
            raise
        else:
            return result



class Index(xbmcup.app.Handler):
    noauth = None

    def handle(self):
        if self._auth():
            try_num, groups = 20, None
            while try_num and groups is None:
                if try_num < 20:
                    xbmc.sleep(1000)
                try_num -= 1
                groups = Files(xbmc.translatePath('special://temp/tvclub/m3u')).read('groups.json')
                if not groups and xbmcvfs.exists('special://temp/tvclub/noauth.pid'):
                    xbmcvfs.delete('special://temp/tvclub/noauth.pid')
                    xbmcup.gui.alert(xbmcup.app.lang[50502], title=u'TVClub')  # Invalid auth
                    break
            else:
                if groups:
                    for group in json.loads(groups):
                        if group[0] == 1:
                            group[1] = u'Избранное' if xbmc.getLanguage(xbmc.ISO_639_1) == 'ru' else u'Favorites'
                        self.item(group[1] + ' - ' + str(group[2]), self.link('channels', gid=group[0]), folder=True, cover=COVER)
        self.render(mode='list', content='files')

    def _auth(self):
        try_num, token = 3, None
        while try_num:
            if not xbmcvfs.exists('special://temp/tvclub/noauth.pid'):
                return True
            f = xbmcvfs.File('special://temp/tvclub/noauth.pid')
            temp = f.read()
            f.close()
            if temp == token:
                xbmc.sleep(1000)
            else:
                try_num -= 1
                token = temp
                old_login = xbmcup.app.setting['login']
                old_password = xbmcup.app.setting['password']
                while True:
                    login = xbmcup.gui.prompt(xbmcup.app.lang[50001], old_login)
                    if not login:
                        return False
                    password = xbmcup.gui.password(xbmcup.app.lang[50002], old_password)
                    if not password:
                        return False
                    if old_login != login or old_password != password:
                        break
                xbmcup.app.setting['login'] = login
                xbmcup.app.setting['password'] = password
        return False


class Channels(xbmcup.app.Handler, API):
    def handle(self):
        if 'favorite_set' in self.argv:
            self.favorite_set(self.argv['favorite_set'], self.argv['channel'])
        elif 'favorite_remove' in self.argv:
            self.favorite_remove(self.argv['favorite_remove'])
        records = json.loads(Files(xbmc.translatePath('special://temp/tvclub/xmltv')).read('records.json') or '{}')
        m3u = Files(xbmc.translatePath('special://temp/tvclub/m3u'))
        favorites = set([x['cid'] for x in json.loads(m3u.read('1.json') or '[]')])
        channels = m3u.read('%s.json' % self.argv['gid'])
        if channels:
            for channel in json.loads(channels):
                cid, name, protected, menu = str(channel['cid']), channel['name'], channel['protected'], []
                if records.get(cid):
                    menu.append((xbmcup.app.lang[50201], self.resolve('archive', record=records[cid], **channel)))
                    name = u'[COLOR FF00FF00]%s[/COLOR]' % name

                if self.argv['gid'] == 1:
                    menu.append((xbmcup.app.lang[50102], self.replace('channels', gid=self.argv['gid'], favorite_set='move', channel=channel)))
                    menu.append((xbmcup.app.lang[50103], self.replace('channels', gid=self.argv['gid'], favorite_remove=channel['cid'])))
                else:
                    if channel['cid'] in favorites:
                        menu.append((xbmcup.app.lang[50103], self.replace('channels', gid=self.argv['gid'], favorite_remove=channel['cid'])))
                    else:
                        menu.append((xbmcup.app.lang[50101], self.replace('channels', gid=self.argv['gid'], favorite_set='add', channel=channel)))
                self.item(name, self.resolve('live', **channel), cover='http://tvclub.us/logo/original/%s.png' % cid, menu=menu, menu_replace=True)
        self.render(mode='thumb')

    def favorite_set(self, action, channel):
        favorites = [x for x in json.loads(Files(xbmc.translatePath('special://temp/tvclub/m3u')).read('1.json') or '[]') if x['cid'] != channel['cid']]
        if favorites:
            items = [
                ('first', u'[COLOR=FF00FF00]%s[/COLOR]' % xbmcup.app.lang[50104]),
                ('last', u'[COLOR=FF00FF00]%s[/COLOR]' % xbmcup.app.lang[50105])
            ]
            items.extend([(i + 2, x['name']) for i, x in enumerate(favorites)])
            pos = xbmcup.gui.select((u'%s:' % xbmcup.app.lang[50106]) if action == 'add' else (u'%s:' % xbmcup.app.lang[50107]), items)
            if not pos:
                return
            if pos == 'first':
                favorites.insert(0, channel)
            elif pos == 'last':
                favorites.append(channel)
            else:
                favorites.insert(pos - 1, channel)

            try:
                self.api('set_favorites', {'cid': channel['cid'], 'pos': pos})
            except:
                pass
            else:
                self.favorite_save(favorites)

    def favorite_remove(self, cid):
        try:
            self.api('set_favorites', {'cid': cid, 'pos': 'del'})
        except:
            pass
        else:
            self.favorite_save([x for x in json.loads(Files(xbmc.translatePath('special://temp/tvclub/m3u')).read('1.json') or '[]') if x['cid'] != cid])

    def favorite_save(self, favorites):
        m3u = Files(xbmc.translatePath('special://temp/tvclub/m3u'))
        fd = m3u.open('1.json', 'w')
        fd.write(json.dumps(favorites))
        fd.close()
        groups = json.loads(m3u.read('groups.json'))
        groups[0][2] = len(favorites)
        fd = m3u.open('groups.json', 'w')
        fd.write(json.dumps(groups))
        fd.close()
        file(xbmc.translatePath('special://temp/tvclub/flush/%s' % int(time.time())), 'w').close()


class Protected(API):
    def protected(self, cid, record=None):
        try:
            url, code = None, xbmcup.app.setting['code']
            if code:
                url = self.get_url(cid, code, record)
            while not url:
                code = xbmcup.gui.password(xbmcup.app.lang[50003])
                if not code:
                    return
                url = self.get_url(cid, code, record)
            return url
        except:
            pass

    def get_url(self, cid, code, record):
        method, params = ('rec', {'cid': cid, 'protected': code, 'time': record}) if record else ('live', {'cid': cid, 'protected': code})
        return self.api(method, params)[method]['url']


class Live(xbmcup.app.Handler, Protected):
    def handle(self):
        if self.argv['protected']:
            return self.protected(self.argv['cid'])
        else:
            return self.argv['url']


class Archive(xbmcup.app.Handler, Protected):
    def handle(self):
        select, epg = [], Files(xbmc.translatePath('special://temp/tvclub/xmltv')).read('epg.%s.json' % self.argv['cid'])
        if epg:
            current = int(time.time())
            for programme in json.loads(epg):
                if programme[0] < current:
                    select.append((programme[0], u'[COLOR FF00FF00]%s[/COLOR]  %s' % (time.strftime('%d.%m %H:%M', time.localtime(programme[0])), programme[2])))
        if not select:
            return
        start = xbmcup.gui.select(self.argv['name'], select)
        if not start:
            return
        start += int(xbmcup.app.setting['timeshift'])
        return self.protected(self.argv['cid'], start) if self.argv['protected'] else self.argv['url'] + '?utc=%s' % start


def run():
    plugin = xbmcup.app.Plugin()
    plugin.route(None, Index)
    plugin.route('channels', Channels)
    plugin.route('live', Live)
    plugin.route('archive', Archive)
    plugin.run()
