# -*- coding: utf-8 -*-

import os
import time


class Transaction:
    def __init__(self, basedir):
        self._basedir = basedir
        self._subdir = str(int(time.time()))
        self._path = os.path.join(basedir, self._subdir)
        if not os.path.isdir(self._path):
            os.mkdir(self._path)

    def commit(self):
        file(os.path.join(self._basedir, 'last.txt'), 'wb').write(self._subdir)

    def open(self, filename, mode='r'):
        path = os.path.join(self._path, filename)
        if mode == 'r' and not os.path.isfile(path):
            return
        return open(path, mode + 'b')

    def read(self, filename):
        fd = self.open(filename)
        if not fd:
            return
        data = fd.read()
        fd.close()
        return data

    def write(self, filename, data):
        fd = self.open(filename, 'w')
        fd.write(data)
        fd.close()
        return True

    def path(self):
        return self._path


class Files:
    def __init__(self, basedir):
        self.basedir = basedir
        if not os.path.isdir(self.basedir):
            os.mkdir(self.basedir)

    def transaction(self):
        self._clear()
        return Transaction(self.basedir)

    def open(self, filename, mode='r'):
        last = self._last()
        if last:
            path = os.path.join(self.basedir, last, filename)
            if mode == 'r' and not os.path.isfile(path):
                return
            return open(path, mode + 'b')

    def read(self, filename):
        fd = self.open(filename)
        if fd:
            data = fd.read()
            fd.close()
            return data

    def write(self, filename, data):
        fd = self.open(filename, 'w')
        if fd:
            fd.write(data)
            fd.close()
            return True
        return False

    def path(self):
        last = self._last()
        if last:
            return os.path.join(self.basedir, last)

    def _last(self):
        filename = os.path.join(self.basedir, 'last.txt')
        if os.path.isfile(filename):
            return file(filename, 'rb').read().strip()

    def _clear(self):
        last = self._last()
        if last:
            last = int(last)
            hour = int(time.time()) - 24*60*60
            for dirname in [x for x in sorted([int(x) for x in os.listdir(self.basedir) if x.isdigit()]) if x < last and x < hour]:
                path = os.path.join(self.basedir, str(dirname))
                for filename in os.listdir(path):
                    os.remove(os.path.join(path, filename))
                os.rmdir(path)
