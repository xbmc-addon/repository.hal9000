# -*- coding: utf-8 -*-

import xbmc

from app.downloader import Downloader


def main():
    downloader = Downloader()
    downloader.loop()
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
        downloader.loop()

if __name__ == '__main__':
    main()
