# -*- coding: utf-8 -*-

import time
import os.path

import xbmc
import xbmcvfs

import xbmcup.app

from tvclub import TVClub, TVClubError

class EPG:
    def __init__(self):
        self.login = None
        self.password = None
        self.path = None
        self.last = 0
        self.lock = False
        self.update = True

    def loop(self):
        if self.lock:
            return
        self.lock = True
        try:
            self.xmltv()
            self.m3u()
        except TVClubError, e:
            xbmc.log(msg='[plugin.video.tvclub] TVClubError (code %s): %s' % (e.code, e.msg), level=xbmc.LOGERROR)
        except Exception, e:
            xbmc.log(msg='[plugin.video.tvclub] Unknown exception: %s' % str(e), level=xbmc.LOGERROR)
        self.lock = False

    def xmltv(self):
        login = xbmcup.app.setting['login']
        password = xbmcup.app.setting['password']
        path = xbmcup.app.setting['path']
        if login and password:
            if self.login != login or self.password != password or self.path != path or self.last + 3*60*60 < int(time.time()):
                if xbmcup.app.setting['epg'] == '1' and path and os.path.isdir(path):
                    start = int(time.time())
                    xmltv = TVClub(xbmc.translatePath('special://temp/tvclub/epg'), login, password).xmltv
                    # TODO: сделать старт и финиш времени
                    xmltv.make(int(time.time()) - 24*60*60, int(time.time()) + 24*60*60)  # -1/+1 день
                    if xmltv.files.copy('tvclub.xmltv.xml', os.path.join(path, 'tvclub.xmltv.xml')):
                        xbmc.log(msg='[plugin.video.tvclub] XMLTV updated. Time: %s sec' % (int(time.time()) - start), level=xbmc.LOGNOTICE)
                        self.login = login
                        self.password = password
                        self.path = path
                        self.last = int(time.time())
                        self.update = True

    def m3u(self):
        if xbmcvfs.exists('special://temp/tvclub/epg/flush.pid'):
            xbmcvfs.delete('special://temp/tvclub/epg/flush.pid')
            self.update = True
        if self.update:
            login = xbmcup.app.setting['login']
            password = xbmcup.app.setting['password']
            path = xbmcup.app.setting['path']
            if login and password and xbmcup.app.setting['epg'] == '1' and path and os.path.isdir(path):
                start = int(time.time())
                m3u = TVClub(xbmc.translatePath('special://temp/tvclub/epg'), login, password).m3u
                if m3u.make():
                    if m3u.files.copy('tvclub.playlist.m3u', os.path.join(path, 'tvclub.playlist.m3u')):
                        xbmc.log(msg='[plugin.video.tvclub] M3U updated. Time: %s sec' % (int(time.time()) - start), level=xbmc.LOGNOTICE)
                        self.update = False
