# -*- coding: utf-8 -*-

import hashlib

import xbmcup.app
import xbmcup.gui
import xbmcup.system

from api import API
from favorites import Favorites


COVER_TVCLUB = xbmcup.system.fs('home://addons/plugin.video.tvclub/resources/media/icons/tvclub.png')
COVER_BACKWARD = xbmcup.system.fs('home://addons/plugin.video.tvclub/resources/media/icons/backward.png')
COVER_FORWARD = xbmcup.system.fs('home://addons/plugin.video.tvclub/resources/media/icons/forward.png')
COVER_FAVORITE = xbmcup.system.fs('home://addons/plugin.video.tvclub/resources/media/icons/favorite.png')


class Index(xbmcup.app.Handler, API):
    def handle(self):
        self.item(u'Избранное', self.link('favorites'), folder=True, cover=COVER_TVCLUB)
        response = self.api('groups')
        if response:
            # TODO: Translate
            groups = [{'gid': x['id'], 'name': x['name_ru']} for x in response['groups']]
            for group in sorted(groups, key=lambda s: s['name']):
                self.item(group['name'], self.link('channels', parameters={'gid': group['gid'], 'page': 1}), folder=True, cover=COVER_TVCLUB)
        self.render(mode='list')


class Channels(xbmcup.app.Handler, API):
    def handle(self):
        favorites_api = Favorites()
        favorites_api.change(self.argv)
        favorites = favorites_api.fetch()

        gid = self.argv['parameters']['gid']
        page = self.argv['parameters']['page']

        response = self.api('channels', {
            'gid': gid,
            'page': page,
            'sort': 3,
            'limit': 200
        })
        if response:
            if response['info']['page'] > 1:
                # TODO: Translate
                self.item(u'Назад - %s/%s' % (response['info']['page'] - 1, response['info']['pages']), self.replace('channels', parameters={'gid': gid, 'page': response['info']['page'] - 1}), folder=True, cover=COVER_BACKWARD)
            for channel in response['channels']:
                menu = None
                if favorites is not None:
                    if channel['info']['id'] in favorites:
                        # TODO: Translate
                        menu = [(u'Удалить из Избранного', self.replace('channels', parameters={'gid': gid, 'page': page}, favorites={'action': 'remove', 'cid': channel['info']['id']}))]
                    else:
                        # TODO: Translate
                        menu = [(u'Добавить в Избранное', self.replace('channels', parameters={'gid': gid, 'page': page}, favorites={'action': 'add', 'cid': channel['info']['id'], 'name': channel['info']['name'], 'protected': channel['info']['protected']}))]
                self.item(
                    channel['info']['name'],
                    self.resolve('live', parameters={'cid': channel['info']['id'], 'protected': channel['info']['protected']}),
                    cover='http://tvclub.us/logo/original/%s.png' % channel['info']['id'],
                    menu=menu,
                    menu_replace=True
                )
            if response['info']['page'] < response['info']['pages']:
                # TODO: Translate
                self.item(u'Вперед - %s/%s' % (response['info']['page'] + 1, response['info']['pages']), self.replace('channels', parameters={'gid': gid, 'page': response['info']['page'] + 1}), folder=True, cover=COVER_FORWARD)
        self.render(mode='thumb')


class FavoritesHandler(xbmcup.app.Handler):
    def handle(self):
        favorites_api = Favorites()
        favorites_api.change(self.argv)
        favorites = favorites_api.get()
        if favorites:
            for cid, name, protected in favorites:
                # TODO: Translate
                self.item(
                    name,
                    self.resolve('live', parameters={'cid': name, 'protected': protected}),
                    cover='http://tvclub.us/logo/original/%s.png' % cid,
                    menu=[
                        # TODO: Translate
                        (u'Переместить канал', self.replace('favorites', favorites={'action': 'move', 'cid': cid, 'name': name, 'protected': protected})),
                        # TODO: Translate
                        (u'Удалить из Избранного', self.replace('favorites', favorites={'action': 'remove', 'cid': cid}))
                    ],
                    menu_replace=True
                )
        self.render(mode='thumb')


class Live(xbmcup.app.Handler, API):
    def handle(self):
        if self.argv['parameters']['protected'] == 1:
            code = xbmcup.app.setting['code']
            if not code:
                # TODO: Translate
                code = xbmcup.gui.prompt(u'Код защиты')
            if code:
                live = self.api('live', {'cid': self.argv['parameters']['cid'], 'protected': code})
                if live:
                    return live['live']['url']
        else:
            login = xbmcup.app.setting['login']
            password = xbmcup.app.setting['password']
            token = hashlib.md5(login + hashlib.md5(password).hexdigest()).hexdigest()
            return 'http://tvclub.us/play/%s/%s' % (token, self.argv['parameters']['cid'])


def run():
    plugin = xbmcup.app.Plugin()
    plugin.route(None, Index)
    plugin.route('favorites', FavoritesHandler)
    plugin.route('channels', Channels)
    plugin.route('live', Live)
    plugin.run()
