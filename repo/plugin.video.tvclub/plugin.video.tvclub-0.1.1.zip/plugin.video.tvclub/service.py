import xbmc

from app.server import Server


def main():
    server = Server()
    server.loop()
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
        server.loop()
    server.stop()

if __name__ == '__main__':
    main()
