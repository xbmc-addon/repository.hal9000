# -*- coding: utf-8 -*-

import time
import threading
from wsgiref.simple_server import make_server, WSGIRequestHandler

from bottle import Bottle, ServerAdapter

import xbmc
import xbmcaddon

import xbmcvfs

from tvclub import TVClub, TVClubError


class App:
    def __init__(self):
        if not xbmcvfs.exists('special://temp/tvclub'):
            xbmcvfs.mkdir('special://temp/tvclub')
        self.deadline = int(xbmcaddon.Addon(id='plugin.video.tvclub').getSetting('deadline'))

    def loop(self):
        if not self.deadline or int(time.time()) > self.deadline:
            try:
                self.fetch()
            except TVClubError, e:
                level = xbmc.LOGWARNING if e.code == 4 else xbmc.LOGERROR
                xbmc.log(msg='[plugin.video.tvclub] [server] TVClub: %s (code %s)' % (e.msg, e.code), level=level)
                self.deadline = int(time.time()) + 5*60  # 5 minutes
            else:
                self.deadline = int(time.time()) + 12*60*60  # 12 hours
                xbmcaddon.Addon(id='plugin.video.tvclub').setSetting('deadline', str(self.deadline))

    def load(self, path, default=None):
        path = 'special://temp/tvclub/' + path
        if xbmcvfs.exists(path):
            f = xbmcvfs.File(path)
            data = f.read()
            f.close()
            return data
        return default

    def fetch(self):
        api = TVClub()
        t = api.groups()
        print str(['GROUPS', t])


class QuietHandler(WSGIRequestHandler):
    def log_request(*args, **kwargs):
        pass


class BottleServer(ServerAdapter):
    server = None

    def run(self, handler):
        if self.quiet:
            self.options['handler_class'] = QuietHandler
        self.server = make_server(self.host, self.port, handler, **self.options)
        self.server.serve_forever()

    def stop(self):
        self.server.shutdown()


class Server:
    def __init__(self):
        self.server = None
        self.port = None
        self.app = App()

    def loop(self):
        port = int(xbmcaddon.Addon(id='plugin.video.tvclub').getSetting('port'))
        if self.port != port:
            self.port = port
            self.stop()
            self.run()
        self.app.loop()

    def run(self):
        threading.Thread(target=self._run).start()

    def _run(self):
        app = Bottle()
        app.route('/xmltv', callback=self.xmltv)
        self.server = BottleServer(host='localhost', port=self.port)
        try:
            app.run(server=self.server)
        except Exception, e:
            xbmc.log(msg='[plugin.video.tvclub] [server] ' + str(e), level=xbmc.LOGERROR)
        xbmc.log(msg='[plugin.video.tvclub] [server] Server stopped', level=xbmc.LOGERROR)
        self.server = None

    def stop(self):
        if self.server:
            self.server.stop()
            while self.server:
                xbmc.sleep(300)

    def xmltv(self):
        return str([time.time()])
