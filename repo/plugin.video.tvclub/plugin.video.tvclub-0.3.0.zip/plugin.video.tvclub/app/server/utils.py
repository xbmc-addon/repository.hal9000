# -*- coding: utf-8 -*-

import time

import xbmcvfs


class FileSystem:
    def load(self, path, default=None):
        path = 'special://temp' + path
        if xbmcvfs.exists(path):
            f = xbmcvfs.File(path)
            data = f.read()
            f.close()
            return data
        return default

    def save(self, path, data):
        f = xbmcvfs.File('special://temp' + path, 'w')
        f.write(data)
        f.close()

    def mkdir(self, path):
        path = 'special://temp' + path
        if not xbmcvfs.exists(path):
            xbmcvfs.mkdirs(path)


def escape(text):
    for f, t in ((u'&', u'&amp;'), (u'"', u'&quot;'), (u"'", u'&apos;'), (u'<', u'&lt;'), (u'>', u'&gt;')):
        text = text.replace(f, t)
    return text


def strftime(sec):
    return time.strftime('%Y%m%d%H%M%S', time.gmtime(sec))
