# -*- coding: utf-8 -*-

import xbmc
from tvclub import TVClubError


class Handler:
    def loop(self):
        try:
            self.handle()
        except TVClubError, e:
            level = xbmc.LOGWARNING if e.code == 4 else xbmc.LOGERROR
            xbmc.log(msg='[plugin.video.tvclub] [server.%s] TVClub API (code %s): %s' % (
                self.__class__.__name__,
                e.code,
                e.msg
            ), level=level)
            self.fail()
        except Exception, e:
            xbmc.log(msg='[plugin.video.tvclub] [server.%s] Exception: %s' % (
                self.__class__.__name__,
                str(e)
            ), level=xbmc.LOGERROR)
            self.fail()
        else:
            self.success()

    def handle(self):
        pass

    def success(self):
        pass

    def fail(self):
        pass
