# -*- coding: utf-8 -*-

import json
import time
import threading

import xbmc
import xbmcvfs
from tvclub import TVClub, TVClubError

from handler import Handler
from utils import FileSystem

THREAD = 10


class Task:
    def __init__(self, start, end):
        self.time_start = int(time.time())
        self.start = start
        self.end = end

        self.file_id = 0
        self.path = str(int(time.time()))
        self.fs = FileSystem()

        self.api = TVClub()
        self.channels = {
            'groups': [],
            'cids': {},
            'channels': {}
        }
        self.error = None
        self.buffer = []
        self.not_found = []

    def run(self):
        self.clear()
        self.fs.mkdir('/tvclub/cache/' + self.path)
        for group in self.api.groups()['groups']:
            gid = str(group['id'])
            # TODO: translate - API отдает названия групп на русском и английском
            self.channels['groups'].append((gid, group['name_ru']))
            self.channels['cids'][gid] = []
            self.get_channels(gid)
        self.fs.save('/tvclub/cache/' + self.path + '/channels.json', json.dumps(self.channels))
        self.fs.save('/tvclub/cache.current.txt', self.path)
        self.fs.save('/tvclub/build/' + str(int(time.time())), '1')
        if self.not_found:
            msg = "[plugin.video.tvclub] [server.Cache] TVClub API (code 9): Channels not found or not allowed: %s" % (
                str(self.not_found),
            )
            xbmc.log(msg=msg, level=xbmc.LOGWARNING)
        total = len(self.channels['channels'])
        xbmc.log(msg='[plugin.video.tvclub] [server.Cache] Cache updated. Channels: %s/%s. Time: %s sec' % (
            total - len(self.not_found),
            total,
            int(time.time()) - self.time_start
        ), level=xbmc.LOGNOTICE)

    def get_channels(self, gid):
        page = 0
        while True:
            page += 1
            channels = self.api.channels(gid, limit=200, page=page, sort=3)
            for channel in channels['channels']:
                cid = str(channel['info']['id'])
                self.channels['cids'][gid].append(cid)
                self.channels['channels'][cid] = (channel['info']['protected'], channel['info']['name'])
            if channels['info']['page'] == channels['info']['pages']:
                break

        if self.channels['cids'][gid]:
            self.get_epg(self.channels['cids'][gid])

    def get_epg(self, cids):
        while cids:
            query = cids[0:THREAD]
            cids = cids[THREAD:]
            if len(query) == 1:
                self.fetch_epg(query[0])
            else:
                pool = []
                for cid in query:
                    pool.append(threading.Thread(target=self.fetch_epg, args=(cid,)))
                for t in pool:
                    t.start()
                for t in pool:
                    t.join()
            if self.error:
                raise self.error
            if len(self.buffer) >= 10:
                self.save()
        self.save()

    def fetch_epg(self, cid):
        current = self.start
        while current < self.end:
            page = 0
            while True:
                page += 1
                try:
                    epg = self.api.epg(time=current, period=30, channels=[cid], limit=200, page=page)
                except TVClubError, e:
                    if e.code == 9:
                        self.not_found.append(cid)
                    else:
                        self.error = e
                    return
                else:
                    for channel in epg['epg']['channels']:
                        if 'epg' in channel and channel['epg']:
                            for programme in channel['epg']:
                                self.buffer.append((str(channel['id']), programme))
                    if epg['info']['page'] == epg['info']['pages']:
                        break
            current += 30*60*60

    def save(self):
        self.file_id += 1
        if self.buffer:
            self.fs.save('/tvclub/cache/' + self.path + '/epg' + str(self.file_id) + '.json', json.dumps(self.buffer))
            self.buffer = []

    def clear(self):
        dirs = sorted([int(x) for x in xbmcvfs.listdir('special://temp/tvclub/cache')[0]])
        while len(dirs) > 2:
            dirname = 'special://temp/tvclub/cache/' + str(dirs.pop(0))
            for filename in xbmcvfs.listdir(dirname)[1]:
                xbmcvfs.delete(dirname + '/' + filename)
            xbmcvfs.rmdir(dirname)


class Cache(Handler):
    def __init__(self):
        self.fs = FileSystem()
        self.fs.mkdir('/tvclub/cache')
        self.task = None
        # TODO: test
        #self.fs.save('/tvclub/cache.deadline.txt', '0')

    def handle(self):
        deadline = int(self.fs.load('/tvclub/cache.deadline.txt', 0))
        if deadline and int(time.time()) < deadline:
            return

        # TODO: перенести период в настройки
        start = int(time.time()) - 24*60*60  # -1 day
        end = int(time.time()) + 24*60*60  # +1 day

        self.task = Task(start, end)
        self.task.run()
        self.task = None
        self.fs.save('/tvclub/cache.deadline.txt', str(int(time.time()) + 3*60*60))  # 3 hours

    def fail(self):
        self.fs.save('/tvclub/cache.deadline.txt', str(int(time.time()) + 5*60))  # 5 minutes
