# -*- coding: utf-8 -*-

import threading
from wsgiref.simple_server import make_server, WSGIRequestHandler

from bottle import Bottle, ServerAdapter, response, redirect, abort

import xbmc
import xbmcaddon
from tvclub import TVClub, TVClubError

from cache import Cache
from builder import Builder
from utils import FileSystem


class App:
    def __init__(self):
        self.lock = dict(cache=False, builder=False)
        self.tasks = dict(cache=Cache(), builder=Builder())

    def loop(self):
        for task in ('cache', 'builder'):
            if not self.lock[task]:
                self.lock[task] = True
                self.tasks[task].loop()
                self.lock[task] = False


class HTTP:
    def __init__(self):
        self.code = None
        self.fs = FileSystem()
        self.api = TVClub()

    def resolve(self, cid):
        try:
            live = self.api.live(cid, protected=self.code)
        except TVClubError, e:
            level = xbmc.LOGWARNING if e.code == 4 or e.code == 13 else xbmc.LOGERROR
            xbmc.log(msg='[plugin.video.tvclub] [server.App] TVClub API (code %s): %s' % (e.code, e.msg), level=level)
            abort(401 if e.code == 4 or e.code == 13 else 500, e.msg)
        except Exception, e:
            xbmc.log(msg='[plugin.video.tvclub] [server.App] Exception: %s' % (str(e),), level=xbmc.LOGERROR)
            abort(500, str(e))
        else:
            redirect(live['live']['url'], 302)

    def xmltv(self):
        data = self.fs.load('/tvclub/xmltv.xml')
        if data:
            response.content_type = 'text/xml; charset=utf-8'
            return data
        else:
            abort(404, 'Not Found')

    def m3u(self):
        data = self.fs.load('/tvclub/playlist.m3u')
        if data:
            response.content_type = 'application/x-mpegURL; charset=utf-8'
            return data
        else:
            abort(404, 'Not Found')


class Server:
    def __init__(self):
        self.server = None
        self.port = None
        self.app = App()
        self.http = HTTP()
        self.code = -1

    def loop(self):
        try:
            port, code = self.get_settings()
        except Exception, e:
            xbmc.log(msg='[plugin.video.tvclub] [server] ' + str(e), level=xbmc.LOGWARNING)
        else:
            if self.code != code:
                self.http.code = code
                self.app.tasks['builder'].code = code
                self.app.tasks['builder'].add_task()
                self.code = code
            if self.port != port:
                self.app.tasks['builder'].port = port
                self.port = port
                self.stop()
                self.run()
        self.app.loop()

    def get_settings(self):
        addon = xbmcaddon.Addon(id='plugin.video.tvclub')
        port, protected_channels, protection_code = (
            int(addon.getSetting('port')),
            int(addon.getSetting('protected_channels')),
            addon.getSetting('protection_code')
        )
        if protected_channels != 2 and protection_code:
            addon.setSetting('protection_code', '')
            protection_code = ''
        return port, (protection_code if protection_code else None)

    def run(self):
        threading.Thread(target=self._run).start()

    def _run(self):
        app = Bottle()
        app.route('/xmltv', callback=self.http.xmltv)
        app.route('/m3u', callback=self.http.m3u)
        app.route('/resolve/<cid>', callback=self.http.resolve)
        self.server = BottleServer(host='localhost', port=self.port)
        try:
            app.run(server=self.server)
        except Exception, e:
            xbmc.log(msg='[plugin.video.tvclub] [server] ' + str(e), level=xbmc.LOGERROR)
        xbmc.log(msg='[plugin.video.tvclub] [server] Server stopped', level=xbmc.LOGERROR)
        self.server = None

    def stop(self):
        if self.server:
            self.server.stop()
            while self.server:
                xbmc.sleep(300)


# BOTTLE WEB SERVER

class QuietHandler(WSGIRequestHandler):
    def log_request(*args, **kwargs):
        pass


class BottleServer(ServerAdapter):
    server = None

    def run(self, handler):
        if self.quiet:
            self.options['handler_class'] = QuietHandler
        self.server = make_server(self.host, self.port, handler, **self.options)
        self.server.serve_forever()

    def stop(self):
        self.server.shutdown()
