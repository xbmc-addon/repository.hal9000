# -*- coding: utf-8 -*-

import json
import time

import xbmc
import xbmcvfs

from tvclub import TVClub

from handler import Handler
from utils import FileSystem, escape, strftime


class XMLTV:
    def __init__(self, code, protected, cache, channels):
        self.code = code
        self.protected = protected
        self.cache = cache
        self.channels = channels
        self.fd = None
        self.fs = FileSystem()
        self.api = TVClub()

    def run(self):
        self.fd = xbmcvfs.File('special://temp/tvclub/xmltv.temp', 'w')
        self.fd.write('<?xml version="1.0" encoding="UTF-8"?><tv generator-info-name="plugin.video.tvclub">')
        self.make_channels()
        self.make_epg()
        self.fd.write('</tv>')
        self.stop()

    def make_channels(self):
        for group in self.channels['groups']:
            cids = self.channels['cids'].get(group[0], [])
            if not self.code:
                cids = [x for x in cids if x not in self.protected and not self.channels['channels'][x][0]]
            for cid in cids:
                self.fd.write((u'<channel id="%s"><display-name>%s</display-name><icon src="%s"/></channel>' % (
                    cid,
                    escape(self.channels['channels'][cid][1]),
                    self.api.logo(cid, 490)
                )).encode('utf8'))

    def make_epg(self):
        for filename in xbmcvfs.listdir('special://temp/tvclub/cache/' + self.cache)[1]:
            if filename != 'channels.json':
                for cid, programme in json.loads(self.fs.load('/tvclub/cache/' + self.cache + '/' + filename, '[]')):
                    if not self.code and (cid in self.protected or self.channels['channels'][cid][0]):
                        continue
                    self.make_programme(cid, programme)

    def make_programme(self, cid, programme):
        text = escape(programme['text']) if isinstance(programme['text'], basestring) else str(programme['text'])
        description = escape(programme['description']) if 'description' in programme else u''
        xml = u'<programme start="%s" stop="%s" channel="%s"><title>%s</title><desc>%s</desc></programme>' % (
            strftime(programme['start']),
            strftime(programme['end']),
            cid,
            text,
            description
        )
        self.fd.write(xml.encode('utf8'))

    def stop(self):
        if self.fd:
            self.fd.close()


class M3U:
    def __init__(self, code, protected, port, cache, channels):
        self.code = code
        self.protected = protected
        self.port = port
        self.cache = cache
        self.channels = channels
        self.fd = None

    def run(self):
        favorites = []
        #favorites = ['xxx', 'yyy', 'zzz']  # TODO: test

        self.fd = xbmcvfs.File('special://temp/tvclub/playlist.temp', 'w')
        self.fd.write('#EXTM3U\n')
        if favorites:
            # TODO: translate - добавить "Favorites"
            self.render([(cid, self.channels['channels'][cid]) for cid in favorites if cid in self.channels['channels']], u'Избранное')
        for gid, name in self.channels['groups']:
            self.render([(cid, self.channels['channels'][cid]) for cid in self.channels['cids'].get(gid, [])], name)
        self.stop()

    def render(self, channels, group):
        if not self.code:
            channels = [x for x in channels if x[0] not in self.protected and not x[1][0]]
        if not channels:
            return
        self.make_channel(channels[0][0], channels[0][1][1], group)
        for cid, name in channels[1:]:
            self.make_channel(cid, name[1])

    def make_channel(self, cid, name, group=None):
        if group:
            text = u'#EXTINF:-1 tvg-id="%s" tvg-name="%s" group-title="%s",%s\n' % (
                cid,
                escape(name).replace(u' ', u'_'),
                group.replace(u'"', u'&quot;'),
                name.replace(u'"', u'&quot;')
            )
        else:
            text = u'#EXTINF:-1 tvg-id="%s" tvg-name="%s",%s\n' % (
                cid,
                escape(name).replace(u' ', u'_'),
                name.replace(u'"', u'&quot;')
            )
        text += u'http://localhost:%s/resolve/%s\n' % (self.port, cid)
        self.fd.write(text.encode('utf8'))

    def stop(self):
        if self.fd:
            self.fd.close()


class Task:
    def __init__(self, code, port):
        self.time_start = int(time.time())
        self.task = None
        self.code = code
        self.port = port
        # This channels is protected but marked as opened
        self.protected = ('372', )

    def run(self):
        fs = FileSystem()
        cache = fs.load('/tvclub/cache.current.txt')
        channels = json.loads(fs.load('/tvclub/cache/' + cache + '/channels.json', '{}'))
        if channels:
            self.task = XMLTV(self.code, self.protected, cache, channels)
            self.task.run()
            self.task = M3U(self.code, self.protected, self.port, cache, channels)
            self.task.run()
            xbmc.log(msg='[plugin.video.tvclub] [server.Builder] XMLTV and M3U updated. Time: %s sec' % (
                int(time.time()) - self.time_start,
            ), level=xbmc.LOGNOTICE)

    def stop(self):
        if self.task:
            self.task.stop()


class Builder(Handler):
    def __init__(self):
        self.fs = FileSystem()
        self.fs.mkdir('/tvclub/build')
        self.task = None
        self.code = None
        self.port = None
        # TODO: test
        #self.add_task()

    def handle(self):
        files = xbmcvfs.listdir('special://temp/tvclub/build')[1]
        if files:
            self.task = Task(self.code, self.port)
            self.task.run()
            self.task = None
            self.rename('xmltv.temp', 'xmltv.xml')
            self.rename('playlist.temp', 'playlist.m3u')
            for filename in files:
                xbmcvfs.delete('special://temp/tvclub/build/' + filename)

    def fail(self):
        if self.task:
            self.task.stop()

    def rename(self, src, dsc):
        if xbmcvfs.exists('special://temp/tvclub/' + src):
            if xbmcvfs.exists('special://temp/tvclub/' + dsc):
                xbmcvfs.delete('special://temp/tvclub/' + dsc)
            xbmcvfs.rename('special://temp/tvclub/' + src, 'special://temp/tvclub/' + dsc)

    def add_task(self):
        self.fs.save('/tvclub/build/' + str(int(time.time())), '1')
