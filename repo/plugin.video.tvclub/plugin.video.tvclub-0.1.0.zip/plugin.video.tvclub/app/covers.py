# -*- coding: utf-8 -*-

import xbmcup.system

tvclub = xbmcup.system.fs('home://addons/plugin.video.tvclub/resources/media/icons/tvclub.png')
backward = xbmcup.system.fs('home://addons/plugin.video.tvclub/resources/media/icons/backward.png')
forward = xbmcup.system.fs('home://addons/plugin.video.tvclub/resources/media/icons/forward.png')
favorite = xbmcup.system.fs('home://addons/plugin.video.tvclub/resources/media/icons/favorite.png')
