# -*- coding: utf-8 -*-

import xbmcup.app
import xbmcup.gui

import covers

from tvclub import TVClub, TVClubError


class Base(xbmcup.app.Handler):
    def auth(self):
        self.parameters = self.argv.get('parameters', {}) if self.argv else {}
        auth = self.argv.get('auth') if self.argv else None
        if not auth:
            return True
        # TODO: Translate
        login = xbmcup.gui.prompt(u'Логин')
        if login:
            password = xbmcup.gui.password(u'Пароль')
            if password:
                try:
                    TVClub().auth(login, password)
                except TVClubError, e:
                    if e.code == 4:
                        # TODO: Translate
                        xbmcup.gui.alert(u'Неверный Логин или Пароль', title=u'Вход')
                    self.error(e)
                    return
                else:
                    return True
        self.error(code=4)  # render auth item

    def error(self, code, msg=None):
        if isinstance(code, TVClubError):
            code, msg = code.code, code.msg
        if code == 4:
            # TODO: Translate
            self.item(u'Вход', self.replace(self.uri, auth=1, parameters=self.parameters), folder=True, cover=covers.tvclub)
        else:
            # TODO: Translate
            xbmcup.gui.alert('%s (code %s)' % (msg, code), title='Error')
        self.render()


class Index(Base):
    uri = None

    def handle(self):
        if self.auth():
            logout = self.argv.get('logout') if self.argv else None
            if logout:
                self.logout()
            else:
                self.index()

    def logout(self):
        try:
            TVClub().logout()
        except TVClubError, e:
            self.error(e)
        else:
            self.error(code=4)

    def index(self):
        try:
            TVClub().account()
        except TVClubError, e:
            self.error(e)
        else:
            self.item(u'Каналы', self.link('groups'), folder=True, cover=covers.tvclub)
            self.item(u'Настройки', self.link('settings'), folder=True, cover=covers.tvclub)
            self.item(u'Выход', self.replace(None, logout=1), folder=True, cover=covers.tvclub)


class Groups(Base):
    uri = 'groups'

    def handle(self):
        if self.auth():
            try:
                groups = TVClub().groups()['groups']
            except TVClubError, e:
                self.error(e)
            else:
                for group in groups:
                    # TODO: Translate
                    self.item(group['name_ru'], self.link('channels', parameters={'gid': group['id']}), folder=True, cover=covers.tvclub)
                self.render()


class Channels(Base):
    uri = 'channels'

    def handle(self):
        if self.auth():
            api = TVClub()
            try:
                channels = api.channels(self.parameters['gid'])['channels']
            except TVClubError, e:
                self.error(e)
            else:
                for channel in channels:
                    # TODO: Translate
                    self.item(
                        channel['info']['name'],
                        self.resolve('live', parameters={'cid': channel['info']['id']}),
                        cover=api.logo(channel['info']['id'], size=300)
                    )
                self.render(mode='thumb')


class Live(Base):
    uri = 'live'

    def handle(self):
        if self.auth():
            try:
                live = TVClub().live(self.parameters['cid'])['live']
            except TVClubError, e:
                self.error(e)
            else:
                return live['url']
