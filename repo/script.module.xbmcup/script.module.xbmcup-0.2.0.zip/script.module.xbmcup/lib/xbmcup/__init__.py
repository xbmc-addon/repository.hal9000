# -*- coding: utf-8 -*-

__author__ = 'hal9000'
__all__ = ['app', 'db', 'cache', 'gui', 'log', 'net', 'parser', 'play', 'skin', 'system', 'test', 'torrent']

version = "0.0.1"
version_info = (0, 0, 1)
