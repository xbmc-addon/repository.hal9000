# -*- coding: utf-8 -*-

__author__ = 'hal9000'
__all__ = ['re', 'html']

import re as regex

class RE(object):
    _compile = {}
    _flag = {'I': regex.I, 'L': regex.L, 'M': regex.M, 'S': regex.S, 'U': regex.U, 'X': regex.X}

    def __call__(self, pattern, string, flag=None):
        return self.find(pattern, string, flag)

    def find(self, pattern, string, flag=None):
        r = self._build(pattern, flag=None).search(string)
        return [x.strip() for x in r.groups()] if r else None

    def all(self, pattern, string, flag=None):
        r = self._build(pattern, flag=None).findall(string)
        if not r:
            return []
        return r if isinstance(r[0], tuple) else [(x,) for x in r]

    def _build(self, pattern, flag=None):
        flag = 'US' if flag is None else flag.upper()

        key = u':'.join([flag, pattern])
        try:
            return self._compile[key]
        except KeyError:
            self._compile[key] = regex.compile(pattern, reduce(lambda r,f: r|f, [self._flag[x] for x in flag]))
            return self._compile[key]


re = RE()


def html(string):
    from bsoup4 import BeautifulSoup
    return BeautifulSoup(string, 'html.parser')
