# -*- coding: utf-8 -*-


"""
Возможные значения data в драйверах:
title (обязательно), label, info, property, icon, cover, fanart, color1, color2, color3
"""

from drivers import finamfm
from drivers import rbc


DRIVERS = {
    1: finamfm,
    2: rbc
}
