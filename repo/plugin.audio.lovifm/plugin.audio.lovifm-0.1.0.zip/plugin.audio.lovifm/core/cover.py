# -*- coding: utf-8 -*-

import xbmcup.system

backward = xbmcup.system.fs('home://addons/plugin.audio.lovifm/resources/media/icons/backward.png')
forward  = xbmcup.system.fs('home://addons/plugin.audio.lovifm/resources/media/icons/forward.png')
favorite  = xbmcup.system.fs('home://addons/plugin.audio.lovifm/resources/media/icons/favorite.png')
lovifm  = xbmcup.system.fs('home://addons/plugin.audio.lovifm/resources/media/icons/lovifm.png')
